// ─── netlify/functions/airtable-proxy.js ─────────────────────────
// SECURITE P0 : Le token Airtable ne quitte JAMAIS le serveur.
// Le client appelle /.netlify/functions/airtable-proxy

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  }

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' }
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) }
  }

  try {
    const { table, method = 'GET', path = '', qs = '', body: reqBody } = JSON.parse(event.body || '{}')

    // Whitelist des tables autorisées
    const ALLOWED_TABLES = ['USERS', 'PAYMENTS', 'INTERPRETATIONS']
    if (!ALLOWED_TABLES.includes(table)) {
      return { statusCode: 403, headers, body: JSON.stringify({ error: 'Table non autorisée.' }) }
    }

    const BASE = process.env.AIRTABLE_BASE_ID
    const TOKEN = process.env.AIRTABLE_TOKEN
    const url = `https://api.airtable.com/v0/${BASE}/${encodeURIComponent(table)}${path}${qs}`

    const opts = {
      method,
      headers: {
        'Authorization': `Bearer ${TOKEN}`,
        'Content-Type': 'application/json',
      },
    }
    if (reqBody) opts.body = JSON.stringify(reqBody)

    let res
    try {
      res = await fetch(url, opts)
    } catch (e) {
      return { statusCode: 503, headers, body: JSON.stringify({ error: `Connexion Airtable impossible. (${e.message})` }) }
    }

    const data = await res.json().catch(() => ({}))

    if (!res.ok) {
      const msg = data?.error?.message ?? data?.error?.type ?? `Erreur Airtable ${res.status}`
      return { statusCode: res.status, headers, body: JSON.stringify({ error: msg }) }
    }

    return { statusCode: 200, headers, body: JSON.stringify(data) }
  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message || 'Erreur serveur.' }) }
  }
}
