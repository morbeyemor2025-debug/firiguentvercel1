// ─── api/airtable-proxy.js — Vercel Serverless Function ──────────
// Converti depuis netlify/functions/airtable-proxy.js
// SECURITE P0 : Le token Airtable ne quitte JAMAIS le serveur.

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS')

  if (req.method === 'OPTIONS') {
    return res.status(200).end()
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const { table, method = 'GET', path = '', qs = '', body: reqBody } = req.body || {}

    // Whitelist des tables autorisées
    const ALLOWED_TABLES = ['USERS', 'PAYMENTS', 'INTERPRETATIONS']
    if (!ALLOWED_TABLES.includes(table)) {
      return res.status(403).json({ error: 'Table non autorisée.' })
    }

    const BASE  = process.env.AIRTABLE_BASE_ID
    const TOKEN = process.env.AIRTABLE_TOKEN
    const url   = `https://api.airtable.com/v0/${BASE}/${encodeURIComponent(table)}${path}${qs}`

    const opts = {
      method,
      headers: {
        'Authorization':  `Bearer ${TOKEN}`,
        'Content-Type':   'application/json',
      },
    }
    if (reqBody) opts.body = JSON.stringify(reqBody)

    let airtableRes
    try {
      airtableRes = await fetch(url, opts)
    } catch (e) {
      return res.status(503).json({ error: `Connexion Airtable impossible. (${e.message})` })
    }

    const data = await airtableRes.json().catch(() => ({}))

    if (!airtableRes.ok) {
      const msg = data?.error?.message ?? data?.error?.type ?? `Erreur Airtable ${airtableRes.status}`
      return res.status(airtableRes.status).json({ error: msg })
    }

    return res.status(200).json(data)

  } catch (err) {
    return res.status(500).json({ error: err.message || 'Erreur serveur.' })
  }
}
