import React, { useState, useEffect } from 'react'
import { MapPin } from 'lucide-react'
import { getPrayerTimesDakar, getPrayerTimesLocal, getActivePrayer, getNextPrayer } from '../utils/prayer.js'

export default function PrayerWidget() {
  const [tab, setTab] = useState('dakar')
  const [prayers, setPrayers] = useState([])
  const [active, setActive] = useState('')
  const [next, setNext] = useState(null)
  const [now, setNow] = useState(new Date())

  useEffect(() => {
    const update = () => {
      const d = new Date()
      setNow(d)
      const p = tab === 'dakar' ? getPrayerTimesDakar(d) : getPrayerTimesLocal(d)
      setPrayers(p)
      setActive(getActivePrayer(p))
      setNext(getNextPrayer(p))
    }
    update()
    const t = setInterval(update, 30000)
    return () => clearInterval(t)
  }, [tab])

  const fmtDate = (d) => d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })
  const fmtHijri = () => {
    try {
      return new Intl.DateTimeFormat('ar-TN-u-ca-islamic', { day: 'numeric', month: 'long', year: 'numeric' }).format(now)
    } catch { return '' }
  }

  return (
    <div className="card p-5 md:p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <div>
          <div className="font-display text-lg font-semibold capitalize" style={{color:'var(--text)'}}>{fmtDate(now)}</div>
          <div style={{fontFamily:"'Scheherazade New',serif", fontSize:'.95rem', color:'var(--gold)', direction:'rtl'}}>{fmtHijri()}</div>
          {next && (
            <div className="text-xs mt-1" style={{color:'var(--text-3)'}}>
              Prochaine prière : <strong style={{color:'var(--blue)'}}>{next.phonetic}</strong>
              {' '}dans <strong style={{color:'var(--green)'}}>{next.countdown}</strong>
            </div>
          )}
        </div>

        {/* Tab selector */}
        <div className="flex gap-1 bg-gray-100 p-1 rounded-xl self-start">
          <button onClick={() => setTab('dakar')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              tab === 'dakar' ? 'bg-white shadow-sm text-[var(--green)]' : 'text-[var(--text-3)] hover:text-[var(--text)]'
            }`}>
            🇸🇳 Dakar
          </button>
          <button onClick={() => setTab('local')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              tab === 'local' ? 'bg-white shadow-sm text-[var(--blue)]' : 'text-[var(--text-3)] hover:text-[var(--text)]'
            }`}>
            🌍 International
          </button>
        </div>
      </div>

      {/* Prayer grid */}
      <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
        {prayers.map(p => {
          const isActive = active === p.key
          return (
            <div key={p.key} className={`prayer-card ${isActive ? 'active-prayer' : ''}`}>
              {/* Arabic name */}
              <div style={{
                fontFamily:"'Scheherazade New',serif", fontSize:'1.1rem',
                color: isActive ? 'var(--green)' : 'var(--gold)', direction:'rtl',
                fontWeight: isActive ? 700 : 400
              }}>{p.ar}</div>
              {/* Phonetic */}
              <div className="text-xs font-semibold mt-0.5" style={{color: isActive ? 'var(--blue-deep)' : 'var(--text-3)'}}>
                {p.phonetic}
              </div>
              {/* Time */}
              <div className="font-bold text-base mt-1" style={{color: isActive ? 'var(--green)' : 'var(--text)'}}>
                {p.time}
              </div>
              {isActive && (
                <div className="text-[10px] mt-0.5 font-medium" style={{color:'var(--green)'}}>● En cours</div>
              )}
            </div>
          )
        })}
      </div>

      <p className="text-xs mt-3 text-center" style={{color:'var(--text-muted)'}}>
        {tab === 'dakar' ? '🇸🇳 Horaires Dakar · Méthode MWL' : '🌍 Horaires approximatifs selon votre fuseau'}
        {' · '}Mise à jour automatique
      </p>
    </div>
  )
}
