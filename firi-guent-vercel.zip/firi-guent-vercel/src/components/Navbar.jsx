import React, { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Home, BookOpen, LayoutDashboard, Menu, X, Sparkles } from 'lucide-react'
import { useAuth } from '../utils/AuthContext.jsx'

const LINKS = [
  { to:'/',             label:'Accueil',         Icon:Home,            public:true  },
  { to:'/interpreter',  label:'Interpréter',     Icon:BookOpen,        public:false },
  { to:'/asmaul-husna', label:"99 Noms",         Icon:Sparkles,        public:true  },
  { to:'/dashboard',    label:'Mes Rêves',       Icon:LayoutDashboard, public:false },
]

// BUG FIX : pas de style inline display:none qui override Tailwind
// Utiliser uniquement les classes Tailwind pour le responsive
export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen]         = useState(false)
  const { pathname }            = useLocation()
  const { user, logout }        = useAuth()

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', h, { passive:true })
    return () => window.removeEventListener('scroll', h)
  }, [])
  useEffect(() => setOpen(false), [pathname])

  const visibleLinks = LINKS.filter(l => l.public || user)

  const accessBadge = () => {
    if (!user) return null
    if (user.plan === 'subscription') {
      return <span className="badge-green" style={{fontSize:11,padding:'2px 8px'}}>♾️ Illimité</span>
    }
    if (Number(user.credits) > 0) {
      return <span className="badge-blue" style={{fontSize:11,padding:'2px 8px'}}>💎 {user.credits} crédit{user.credits > 1 ? 's' : ''}</span>
    }
    if (!user.free_used) {
      return <span className="badge-green" style={{fontSize:11,padding:'2px 8px'}}>🎁 1 gratuit</span>
    }
    return <span style={{fontSize:11,background:'#FEE2E2',color:'#991B1B',border:'1px solid #FCA5A5',borderRadius:20,padding:'2px 8px',fontWeight:600}}>🔒 Recharger</span>
  }

  const navBg = scrolled
    ? { background:'rgba(255,255,255,.97)', boxShadow:'0 2px 20px rgba(0,0,0,.1)', backdropFilter:'blur(8px)' }
    : { background:'rgba(12,31,20,.92)' }

  const linkColor = (to) => scrolled
    ? (pathname === to ? 'var(--blue-text)' : 'var(--text-3)')
    : (pathname === to ? '#6EE7B7'          : '#D1D5DB')

  return (
    <header className="fixed top-0 inset-x-0 z-50 transition-all duration-300 sen-border-top" style={navBg}>
      <nav style={{ maxWidth:1100, margin:'0 auto', padding:'0 20px', height:64, display:'flex', alignItems:'center', justifyContent:'space-between' }}>

        {/* Logo */}
        <Link to="/" style={{ display:'flex', alignItems:'center', gap:8, textDecoration:'none', flexShrink:0 }}>
          <span style={{ fontSize:22 }}>🌙</span>
          <div>
            <div style={{ fontFamily:"'Amiri',serif", fontSize:18, fontWeight:700, color: scrolled ? 'var(--green)' : '#F9FAFB', lineHeight:1.1 }}>
              Firi Guent
            </div>
            <div style={{ fontFamily:"'Scheherazade New',serif", fontSize:10, color: scrolled ? 'var(--blue)' : '#6EE7B7', opacity:.8, direction:'rtl' }}>
              تفسير الأحلام
            </div>
          </div>
        </Link>

        {/* Desktop nav — FIX : utiliser flex directement, pas display:none + md:flex */}
        <div className="hidden md:flex" style={{ alignItems:'center', gap:4 }}>
          {visibleLinks.map(({ to, label, Icon }) => (
            <Link key={to} to={to}
              style={{ display:'flex', alignItems:'center', gap:5, padding:'7px 12px', borderRadius:10, fontSize:13, fontWeight:500, textDecoration:'none', transition:'all .18s',
                background: pathname === to ? (scrolled ? 'var(--blue-pale)' : 'rgba(255,255,255,.12)') : 'transparent',
                color: linkColor(to),
              }}>
              <Icon size={13}/>{label}
            </Link>
          ))}
          {accessBadge()}
          {user ? (
            <div style={{ display:'flex', alignItems:'center', gap:6, marginLeft:8, borderLeft:'1px solid rgba(255,255,255,.15)', paddingLeft:10 }}>
              <span style={{ fontSize:12, color: scrolled ? 'var(--text-3)' : '#9CA3AF', maxWidth:120, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                {user.email?.split('@')[0]}
              </span>
              <button onClick={logout}
                style={{ background:'none', border:'1px solid rgba(239,68,68,.4)', borderRadius:8, padding:'5px 10px', cursor:'pointer', color:'#DC2626', display:'flex', alignItems:'center', gap:4, fontSize:12, whiteSpace:'nowrap' }}>
                Déco
              </button>
            </div>
          ) : (
            <Link to="/login" className="btn btn-primary" style={{ marginLeft:8, padding:'8px 18px', fontSize:13, borderRadius:10, whiteSpace:'nowrap' }}>
              Connexion
            </Link>
          )}
        </div>

        {/* Mobile burger */}
        <button onClick={() => setOpen(v => !v)} className="md:hidden"
          style={{ background:'none', border:'none', cursor:'pointer', color: scrolled ? 'var(--text-3)' : '#D1D5DB', padding:8 }}>
          {open ? <X size={22}/> : <Menu size={22}/>}
        </button>
      </nav>

      {/* Mobile menu */}
      {open && (
        <div style={{ background:'#fff', borderTop:'1px solid #f3f4f6', boxShadow:'0 8px 24px rgba(0,0,0,.1)', padding:12 }}>
          {visibleLinks.map(({ to, label, Icon }) => (
            <Link key={to} to={to}
              style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderRadius:10, marginBottom:4, fontSize:15, fontWeight:500, textDecoration:'none',
                color: pathname === to ? 'var(--blue-text)' : 'var(--text-2)',
                background: pathname === to ? 'var(--blue-pale)' : 'transparent' }}>
              <Icon size={16}/>{label}
            </Link>
          ))}
          <div style={{ padding:'8px 16px 4px' }}>{accessBadge()}</div>
          {user ? (
            <button onClick={logout}
              style={{ width:'100%', display:'flex', alignItems:'center', justifyContent:'center', gap:6, padding:'12px', marginTop:8, background:'#FEF2F2', border:'1px solid #FCA5A5', borderRadius:10, color:'#DC2626', fontSize:14, fontWeight:600, cursor:'pointer' }}>
              Déconnexion ({user.email?.split('@')[0]})
            </button>
          ) : (
            <Link to="/login" className="btn btn-primary" style={{ width:'100%', justifyContent:'center', padding:'13px', marginTop:8, borderRadius:10, fontSize:15, display:'flex', alignItems:'center' }}>
              🌙 Se connecter
            </Link>
          )}
        </div>
      )}
    </header>
  )
}
