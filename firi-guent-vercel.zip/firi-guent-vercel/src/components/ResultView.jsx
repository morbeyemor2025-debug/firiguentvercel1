// ─── ResultView.jsx v21 ───────────────────────────────────────────
// P2 : Résultat gratuit tronqué aux 2 premiers paragraphes
//      Hook IA personnalisé dans le bloc premium
// P3 : Bouton Wave direct pour l'upgrade

import React, { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { RefreshCw, Share2, Copy, CheckCircle, Lock } from 'lucide-react'
import { waExpertLink, waUnlockLink, PACKS, TIMES, PRICE_DISPLAY, WAVE_PAY_BASE } from '../utils/constants.js'
import { generatePaywallHook } from '../utils/api.js'
import { createPayment } from '../utils/airtable.js'

// P3 : Lien Wave direct
function waveDirectLink(pack) {
  return `${WAVE_PAY_BASE}?amount=${pack.price}`
}

function Prose({ text, truncate = false }) {
  const nodes = useMemo(() => {
    if (!text) return []
    const lines = text.split('\n').filter(l => l.trim())

    // P2 : Tronquer après les 2 premiers blocs de paragraphes (hors titres)
    let paraCount = 0
    let cutIndex = lines.length
    if (truncate) {
      for (let i = 0; i < lines.length; i++) {
        const t = lines[i].trim()
        const isTitle = /^\*\*[^*]+\*\*$/.test(t) || /^#+/.test(t)
        const isArabic = /[\u0600-\u06FF]{5,}/.test(t)
        const isSep = /^---+$/.test(t)
        if (!isTitle && !isArabic && !isSep && t.length > 20) {
          paraCount++
          // Couper après le 2ème paragraphe substantiel (section "Interprétation globale" incluse)
          if (paraCount >= 4) {
            cutIndex = i
            break
          }
        }
      }
    }

    return lines.slice(0, truncate ? cutIndex : lines.length).map((line, i) => {
      const t = line.trim()
      if (/^\*\*[^*]+\*\*$/.test(t)) {
        return <span key={i} className="st">{t.replace(/\*\*/g, '')}</span>
      }
      if (/[\u0600-\u06FF]{5,}/.test(t)) {
        return (
          <div key={i} className="arabic-block my-4">
            <div className="arabic-script">{t.replace(/\*\*/g, '')}</div>
          </div>
        )
      }
      if (/^---+$/.test(t)) return <hr key={i} style={{ margin:'12px 0', borderColor:'var(--card-border)' }} />
      return (
        <p key={i} className="my-2"
          dangerouslySetInnerHTML={{ __html: t.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>') }} />
      )
    })
  }, [text, truncate])
  return <div className="prose-r">{nodes}</div>
}

function CopyBtn({ text, label = 'Copier' }) {
  const [copied, setCopied] = useState(false)
  const copy = async () => {
    try { await navigator.clipboard.writeText(text) } catch {
      const el = document.createElement('textarea')
      el.value = text; document.body.appendChild(el); el.select()
      document.execCommand('copy'); document.body.removeChild(el)
    }
    setCopied(true); setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button onClick={copy}
      style={{ padding:'7px 10px', borderRadius:8, border:'1.5px solid var(--card-border)', background:'#fff', cursor:'pointer', color: copied ? 'var(--green)' : 'var(--text-muted)', display:'flex', alignItems:'center', gap:4, fontSize:12, transition:'all .2s', whiteSpace:'nowrap' }}>
      {copied ? <CheckCircle size={13}/> : <Copy size={13}/>}
      {copied ? 'Copié !' : label}
    </button>
  )
}

const WaIcon = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.127.558 4.126 1.533 5.859L.057 23.62a.5.5 0 00.598.65l5.956-1.558A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22a9.944 9.944 0 01-5.13-1.415l-.363-.217-3.773.987.997-3.676-.237-.378A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
  </svg>
)

export default function ResultView({ result, form, dreamId, onRestart, user }) {
  const [hookText, setHookText] = useState(null)
  const [hookLoading, setHookLoading] = useState(false)
  const [paidPack, setPaidPack] = useState(null)

  const tLabel = TIMES.find(t => t.v === form?.time)?.label ?? form?.time
  const isFree = !result?.premium

  // Charger le hook IA personnalisé au montage (P2)
  React.useEffect(() => {
    if (!isFree) return
    setHookLoading(true)
    generatePaywallHook({ text: form?.text, emotion: form?.emotion, time: form?.time })
      .then(hook => { if (hook) setHookText(hook) })
      .catch(() => {})
      .finally(() => setHookLoading(false))
  }, [])

  const handleWaveClick = async (pack) => {
    setPaidPack(pack)
    if (user?.id) {
      try { await createPayment(user.id, pack.price, user.email || '', dreamId || '') } catch {}
    }
  }

  const share = () => {
    const txt = `J'ai reçu une interprétation islamique de mon rêve sur Firi Guent : ${window.location.origin}`
    if (navigator.share) navigator.share({ title:'Firi Guent', text:txt, url:window.location.origin }).catch(()=>{})
    else navigator.clipboard?.writeText(txt).catch(()=>{})
  }

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>

      {/* Reference */}
      {dreamId && (
        <div className="card-blue" style={{ padding:'12px 18px', display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:10 }}>
          <div>
            <div className="label-sm" style={{ color:'var(--blue)', marginBottom:3 }}>Référence de votre rêve</div>
            <div style={{ fontFamily:"'Amiri',serif", fontSize:22, fontWeight:700, color:'var(--blue-text)', letterSpacing:'0.05em' }}>#{dreamId}</div>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <span style={{ fontSize:11, color:'var(--text-muted)' }}>Conservez ce numéro</span>
            <CopyBtn text={dreamId} />
          </div>
        </div>
      )}

      {/* Result */}
      <div className="card" style={{ padding:'24px 24px 20px' }}>
        <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:12, marginBottom:18 }}>
          <div>
            <div className="label-sm" style={{ color:'var(--green)', marginBottom:4 }}>
              تفسير الرُّؤْيَا · Tafsir ar-Ru'ya
            </div>
            <h2 style={{ fontFamily:"'Amiri',serif", fontSize:'1.5rem', fontWeight:700, color:'var(--text)', marginBottom:3 }}>
              Votre Interprétation
            </h2>
            <p style={{ fontSize:12, color:'var(--text-muted)', margin:0 }}>Sheikh Momar · Ibn Sirin · Al-Nabulsi · Dakar 🇸🇳</p>
          </div>
          <div style={{ display:'flex', gap:6, flexShrink:0 }}>
            <CopyBtn text={result?.text || ''} label="Copier" />
            <button onClick={share}
              style={{ padding:'7px 10px', borderRadius:8, border:'1.5px solid var(--card-border)', background:'#fff', cursor:'pointer', color:'var(--text-muted)', display:'flex', alignItems:'center', gap:4, fontSize:12 }}>
              <Share2 size={13}/> Partager
            </button>
          </div>
        </div>

        {/* Dream recap */}
        <div style={{ padding:'12px 14px', background:'var(--bg)', border:'1.5px solid var(--card-border)', borderRadius:10, marginBottom:16 }}>
          <div className="label-sm" style={{ color:'var(--text-muted)', marginBottom:6 }}>Rêve analysé</div>
          <p style={{ fontSize:13, color:'var(--text-2)', fontStyle:'italic', margin:'0 0 4px', display:'-webkit-box', WebkitLineClamp:3, WebkitBoxOrient:'vertical', overflow:'hidden' }}>
            "{form?.text}"
          </p>
          <div style={{ display:'flex', flexWrap:'wrap', gap:10, fontSize:11, color:'var(--text-muted)' }}>
            {form?.emotion && <span>Émotion : {form.emotion}</span>}
            {tLabel && <><span>·</span><span>{tLabel}</span></>}
          </div>
        </div>

        {/* P2 : Résultat tronqué pour version gratuite */}
        <Prose text={result?.text} truncate={isFree} />

        {/* Fade-out pour le résultat tronqué */}
        {isFree && (
          <div style={{ position:'relative', height:60, marginTop:-20, background:'linear-gradient(to bottom, transparent, var(--card, white))', pointerEvents:'none' }} />
        )}

        {!isFree && (
          <div className="arabic-block" style={{ marginTop:20 }}>
            <div className="arabic-script">وَاللَّهُ أَعْلَمُ</div>
            <div className="arabic-phonetic">Wallahu A'lam</div>
            <div className="arabic-translation">Et Allah seul connaît la vérité absolue</div>
          </div>
        )}
      </div>

      {/* P2+P3 : Bloc Premium avec hook IA + Wave direct */}
      {isFree && (
        <div className="card-green" style={{ padding:'24px', position:'relative', overflow:'hidden' }}>
          <div className="geo" style={{ position:'absolute', inset:0, opacity:.5, pointerEvents:'none' }}/>
          <div style={{ position:'relative', zIndex:1 }}>
            <div style={{ display:'flex', alignItems:'flex-start', gap:14, marginBottom:16 }}>
              <div style={{ fontSize:30, flexShrink:0 }}>✨</div>
              <div>
                <h3 style={{ fontFamily:"'Amiri',serif", fontSize:'1.2rem', fontWeight:700, color:'var(--text)', marginBottom:4 }}>
                  Analyse complète disponible
                </h3>
                <p style={{ fontSize:13, color:'var(--text-3)', lineHeight:1.6, margin:0 }}>
                  Symboles secondaires · Hadiths Bukhari/Muslim · Cas Compagnons ﷺ · Du'a arabe complet · Experts sénégalais
                </p>
              </div>
            </div>

            {/* P2 : Hook IA personnalisé ou fallback générique */}
            <div style={{ padding:'14px', background:'var(--gold-pale)', border:'1px solid #FDE68A', borderRadius:10, marginBottom:16, fontSize:13, color:'var(--text-2)', lineHeight:1.7, fontStyle:'italic' }}>
              {hookLoading ? (
                <span style={{ color:'var(--text-muted)' }}>Sheikh Momar analyse les symboles secondaires…</span>
              ) : hookText ? (
                <><span style={{ marginRight:6 }}>🔮</span>{hookText}</>
              ) : (
                <><span style={{ marginRight:6 }}>🔮</span>Ibn Sirin identifie plusieurs symboles secondaires dans votre rêve qui révèlent une guidance spirituelle profonde. L'analyse complète dévoile les hadiths précis et les cas des Compagnons du Prophète ﷺ liés à cette vision. Pour découvrir l'intégralité de ce message divin, <em style={{color:'var(--gold)'}}>In sha Allah</em>…</>
              )}
            </div>

            {/* Aperçu flou du reste */}
            <div style={{ position:'relative', marginBottom:16 }}>
              <div style={{ padding:'14px', background:'var(--bg)', borderRadius:10, filter:'blur(4px)', userSelect:'none', pointerEvents:'none', fontSize:13, color:'var(--text-3)', lineHeight:1.7 }}>
                Ibn Sirin précise dans son Tafsir al-Ahlam que ce type de vision appartient aux rêves de guidance divine (Ru'ya Rahmâniyya). Les symboles secondaires révèlent... Le Calife Omar ibn Al-Khattab a vécu une vision similaire... La prescription spirituelle recommandée est de lire...
              </div>
              <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center' }}>
                <div style={{ background:'rgba(255,255,255,.92)', backdropFilter:'blur(4px)', borderRadius:12, padding:'12px 20px', textAlign:'center', border:'1.5px solid var(--card-border)' }}>
                  <Lock size={20} style={{ color:'var(--blue)', display:'block', margin:'0 auto 6px' }}/>
                  <div style={{ fontSize:13, fontWeight:600, color:'var(--text)' }}>Réservé à l'analyse complète</div>
                </div>
              </div>
            </div>

            {/* P3 : Boutons Wave directs */}
            {!paidPack && (
              <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
                {PACKS.map(pack => (
                  <a key={pack.id}
                    href={waveDirectLink(pack)}
                    target="_blank"
                    rel="noreferrer"
                    onClick={() => handleWaveClick(pack)}
                    style={{
                      display:'flex', alignItems:'center', gap:12, padding:'13px 16px', borderRadius:12,
                      border: pack.popular ? '2.5px solid var(--blue)' : '1.5px solid var(--card-border)',
                      background: pack.popular ? 'var(--blue-pale)' : '#fff',
                      textDecoration:'none', transition:'all .18s', cursor:'pointer',
                      boxShadow: pack.popular ? '0 4px 16px rgba(30,64,175,.15)' : 'var(--card-shadow)',
                    }}>
                    <svg width="20" height="20" viewBox="0 0 40 40" fill={pack.popular ? '#1B5EE5' : '#64748b'}>
                      <circle cx="20" cy="20" r="18" fill="none" stroke={pack.popular ? '#1B5EE5' : '#64748b'} strokeWidth="2"/>
                      <text x="20" y="26" textAnchor="middle" fontSize="18" fontWeight="bold">W</text>
                    </svg>
                    <div style={{ flex:1 }}>
                      <div style={{ fontWeight:700, fontSize:14, color: pack.popular ? 'var(--blue-text)' : 'var(--text)' }}>
                        {pack.label} — {pack.fcfa}
                      </div>
                      {pack.bonus && <div style={{ fontSize:11, color:'var(--gold)', marginTop:2 }}>🎁 {pack.bonus}</div>}
                    </div>
                    {pack.popular && (
                      <span style={{ fontSize:11, fontWeight:700, background:'var(--blue)', color:'#fff', borderRadius:20, padding:'3px 10px', flexShrink:0 }}>
                        Populaire
                      </span>
                    )}
                  </a>
                ))}
                <p style={{ fontSize:11, color:'var(--text-muted)', textAlign:'center', marginTop:4 }}>
                  Paiement Wave sécurisé · Accès immédiat · <em style={{ color:'var(--gold)' }}>In sha Allah</em>
                </p>
              </div>
            )}

            {/* Confirmation post-paiement */}
            {paidPack && (
              <div style={{ background:'#fff', borderRadius:12, padding:'16px', border:'1px solid var(--card-border)' }}>
                <div style={{ fontWeight:600, color:'var(--text)', marginBottom:10 }}>
                  ✅ Wave ouvert — {paidPack.label} ({paidPack.fcfa})
                </div>
                <p style={{ fontSize:13, color:'var(--text-3)', lineHeight:1.7, margin:'0 0 12px' }}>
                  Complétez le paiement dans Wave. Vos crédits seront ajoutés automatiquement. <em style={{ color:'var(--gold)' }}>In sha Allah</em>
                </p>
                <div style={{ display:'flex', gap:8 }}>
                  <a href={waveDirectLink(paidPack)} target="_blank" rel="noreferrer"
                    style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', gap:6, padding:'11px', borderRadius:10, background:'#1B5EE5', color:'#fff', textDecoration:'none', fontWeight:700, fontSize:13 }}>
                    Ouvrir Wave
                  </a>
                  <CopyBtn text={`Ref: ${dreamId || '—'} — Email: ${user?.email || '—'}`} label="Copier ref" />
                </div>
                <button onClick={() => setPaidPack(null)}
                  style={{ background:'none', border:'none', color:'var(--text-muted)', fontSize:12, cursor:'pointer', marginTop:8, textDecoration:'underline' }}>
                  ← Changer de pack
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Expert CTA */}
      <div className="card" style={{ padding:'18px 20px', display:'flex', flexDirection:'column', gap:10 }}>
        <div style={{ fontSize:14, fontWeight:600, color:'var(--text)' }}>🕌 Parler à un expert directement</div>
        <p style={{ fontSize:13, color:'var(--text-3)', margin:0 }}>
          Sadaqa, Istikhar, guidance spirituelle — nos experts sénégalais répondent personnellement.
        </p>
        <a href={waExpertLink(user?.email || user?.name || '')} target="_blank" rel="noreferrer"
          className="btn btn-wa" style={{ justifyContent:'center', borderRadius:12, padding:'12px' }}>
          <WaIcon size={17}/> Consulter un expert
        </a>
      </div>

      {/* Action buttons */}
      <div style={{ display:'flex', gap:10 }}>
        <button onClick={onRestart} className="btn btn-outline"
          style={{ flex:1, justifyContent:'center', padding:'13px', borderRadius:12 }}>
          <RefreshCw size={15}/> Nouveau rêve
        </button>
        <Link to="/dashboard" className="btn btn-primary"
          style={{ flex:1, justifyContent:'center', padding:'13px', borderRadius:12 }}>
          Voir mon historique
        </Link>
      </div>
    </div>
  )
}
