import React from 'react'
import { ISLAMIC_EVENTS } from '../utils/constants.js'

export default function IslamicCalendar() {
  const today = new Date()
  const months = { janvier:0,février:1,mars:2,avril:3,mai:4,juin:5,juillet:6,août:7,septembre:8,octobre:9,novembre:10,décembre:11 }

  const upcoming = ISLAMIC_EVENTS.filter(ev => {
    const p = ev.gregorian.split(' ')
    const d = parseInt(p[0]), m = months[p[1]?.toLowerCase()], y = parseInt(p[2])
    if (isNaN(d) || m === undefined || isNaN(y)) return true
    return new Date(y, m, d) >= new Date(today.getFullYear(), today.getMonth(), today.getDate())
  }).slice(0, 5)

  return (
    <div className="card p-5">
      <div className="flex items-center gap-3 mb-4">
        <span style={{fontFamily:"'Scheherazade New',serif", fontSize:'1.3rem', color:'var(--gold)'}}>
          التقويم الهجري
        </span>
        <div>
          <div className="text-xs font-semibold" style={{color:'var(--green)'}}>Taqwim al-Hijri</div>
          <div className="text-xs" style={{color:'var(--text-3)'}}>Calendrier islamique</div>
        </div>
      </div>
      <div className="space-y-2">
        {upcoming.map((ev, i) => (
          <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 border border-gray-100">
            <span className="text-xl flex-shrink-0">{ev.icon}</span>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold truncate" style={{color:'var(--text)'}}>{ev.name}</div>
              <div className="text-xs" style={{color:'var(--text-3)'}}>{ev.gregorian}</div>
            </div>
            <div className="text-xs text-right flex-shrink-0" style={{color:'var(--gold)',fontFamily:"'Amiri',serif"}}>
              {ev.hijri.split(' ').slice(0,2).join(' ')}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
