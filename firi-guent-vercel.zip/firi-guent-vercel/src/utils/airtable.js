// ─── airtable.js v21 — SÉCURISÉ ──────────────────────────────────
// P0 : Le token Airtable n'est plus dans ce fichier.
// Tous les appels passent par /.netlify/functions/airtable-proxy
// Le token est uniquement dans les env vars Netlify.

import { API_AIRTABLE } from './constants.js'

async function req(table, path = '', qs = '', method = 'GET', body = null) {
  let res
  try {
    res = await fetch(API_AIRTABLE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ table, path, qs, method, body }),
    })
  } catch (e) {
    throw new Error(`Connexion impossible. Vérifiez votre connexion. (${e.message})`)
  }

  const data = await res.json().catch(() => ({}))

  if (!res.ok) {
    throw new Error(data?.error ?? `Erreur ${res.status}`)
  }

  return data
}

// ─── USERS ────────────────────────────────────────────────────────

export async function getUserByEmail(email) {
  const e       = email.toLowerCase().trim()
  const formula = encodeURIComponent(`{email}="${e}"`)
  const data    = await req('USERS', '', `?filterByFormula=${formula}&maxRecords=1`)
  return data.records?.[0] ?? null
}

export async function createUser(email, phone = '') {
  const fields = {
    email:     email.toLowerCase().trim(),
    free_used: false,
    plan:      'free',
    credits:   0,
  }
  if (phone) fields.phone = phone
  const data = await req('USERS', '', '', 'POST', { records: [{ fields }] })
  return data.records[0]
}

export async function updateUser(recordId, fields) {
  return req('USERS', `/${recordId}`, '', 'PATCH', { fields })
}

export async function getUserById(recordId) {
  return req('USERS', `/${recordId}`)
}

export async function getAllUsers() {
  const records = []
  let offset = ''
  do {
    const qs   = offset ? `?offset=${encodeURIComponent(offset)}` : ''
    const data = await req('USERS', '', qs)
    records.push(...(data.records ?? []))
    offset = data.offset ?? ''
  } while (offset && records.length < 2000)
  return records
}

// ─── PAYMENTS ─────────────────────────────────────────────────────

export async function createPayment(userId, amount, userEmail = '', ref = '') {
  const fields = {
    user_id: [userId],
    amount:  Number(amount),
    status:  'pending',
  }
  if (userEmail) fields.user_email = userEmail
  if (ref)       fields.ref        = ref

  try {
    const data = await req('PAYMENTS', '', '', 'POST', { records: [{ fields }] })
    return data.records[0]
  } catch (e) {
    if (e.message?.includes('UNKNOWN_FIELD') || e.message?.includes('unknown field')) {
      const minFields = { user_id: [userId], amount: Number(amount), status: 'pending' }
      const data = await req('PAYMENTS', '', '', 'POST', { records: [{ fields: minFields }] })
      return data.records[0]
    }
    throw e
  }
}

export async function getAllPayments() {
  const records = []
  let offset = ''
  do {
    const qs   = offset ? `?offset=${encodeURIComponent(offset)}` : ''
    const data = await req('PAYMENTS', '', qs)
    records.push(...(data.records ?? []))
    offset = data.offset ?? ''
  } while (offset && records.length < 2000)
  return records
}

export async function validatePayment(paymentRecordId, userId, amount) {
  const userRec = await getUserById(userId)
  if (!userRec) throw new Error('Utilisateur introuvable')
  const f = userRec.fields ?? {}

  await req('PAYMENTS', `/${paymentRecordId}`, '', 'PATCH', { fields: { status: 'validated' } })

  if (Number(amount) >= 5000) {
    const end = new Date()
    end.setDate(end.getDate() + 30)
    await req('USERS', `/${userId}`, '', 'PATCH', {
      fields: {
        plan:             'subscription',
        subscription_end: end.toISOString().split('T')[0],
        credits:          0,
      }
    })
  } else {
    await req('USERS', `/${userId}`, '', 'PATCH', {
      fields: {
        plan:    'one_time',
        credits: (Number(f.credits) || 0) + 1,
      }
    })
  }
}

// ─── INTERPRETATIONS ──────────────────────────────────────────────

export async function saveInterpretation(userId, dreamText, result, userEmail = '') {
  const fields = {
    user_id:    [userId],
    dream_text: (dreamText || '').slice(0, 10000),
    result:     (result    || '').slice(0, 50000),
  }
  if (userEmail) fields.user_email = userEmail

  try {
    const data = await req('INTERPRETATIONS', '', '', 'POST', { records: [{ fields }] })
    return data.records[0]
  } catch (e) {
    if (e.message?.includes('UNKNOWN_FIELD') || e.message?.includes('unknown field')) {
      const minFields = { user_id: [userId], dream_text: fields.dream_text, result: fields.result }
      const data = await req('INTERPRETATIONS', '', '', 'POST', { records: [{ fields: minFields }] })
      return data.records[0]
    }
    throw e
  }
}

export async function getUserInterpretations(userId) {
  const formula = encodeURIComponent(`FIND("${userId}", ARRAYJOIN({user_id}))`)
  const data    = await req('INTERPRETATIONS', '', `?filterByFormula=${formula}&maxRecords=50`)
  return data.records ?? []
}

export async function getAllInterpretations() {
  const records = []
  let offset = ''
  do {
    const qs   = offset ? `?offset=${encodeURIComponent(offset)}` : ''
    const data = await req('INTERPRETATIONS', '', qs)
    records.push(...(data.records ?? []))
    offset = data.offset ?? ''
  } while (offset && records.length < 2000)
  return records
}
