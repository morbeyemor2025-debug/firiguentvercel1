// ─── auth.js v17 ─────────────────────────────────────────────────
// BUG CORRIGÉ : refreshSession récupère TOUJOURS le vrai état depuis
// Airtable — free_used, credits, plan — sans faire confiance au cache.
import { getUserByEmail, createUser, updateUser } from './airtable.js'

const SESSION_KEY = 'fg14_session'

export function getSession() {
  try   { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null') }
  catch { return null }
}
export function setSession(user) {
  try { localStorage.setItem(SESSION_KEY, JSON.stringify(user)) } catch {}
}
export function clearSession() {
  try { localStorage.removeItem(SESSION_KEY) } catch {}
}

// ─── Login / Register ─────────────────────────────────────────────
export async function loginOrRegister(email, phone = '') {
  const e = email.toLowerCase().trim()
  if (!e || !e.includes('@')) throw new Error('Email invalide.')

  let record = await getUserByEmail(e)
  if (!record) {
    record = await createUser(e, phone)
  } else if (phone && !record.fields?.phone) {
    try { await updateUser(record.id, { phone }) } catch {}
  }

  const session = buildSession(record)
  setSession(session)
  return session
}

function buildSession(record) {
  const f = record?.fields ?? {}
  const phone = Array.isArray(f.phone) ? f.phone[0] : (f.phone || '')
  return {
    id:               record.id,
    email:            f.email            || '',
    phone,
    free_used:        f.free_used        ?? false,
    plan:             f.plan             || 'free',
    credits:          Number(f.credits   || 0),
    subscription_end: f.subscription_end || null,
    status:           f.status           || 'free',
  }
}

// ─── Refresh DEPUIS Airtable (source de vérité) ───────────────────
// BUG CORRIGÉ : on NE fait plus confiance au cache pour free_used/credits.
// On relit depuis Airtable à chaque fois.
export async function refreshSession() {
  const session = getSession()
  if (!session?.email) return null

  try {
    const fresh = await getUserByEmail(session.email)
    if (!fresh) {
      // Utilisateur introuvable dans Airtable → effacer le cache corrompu
      clearSession()
      return null
    }
    const updated = buildSession(fresh)
    setSession(updated)
    return updated
  } catch {
    // Réseau KO → retourner le cache mais NE PAS le considérer comme source de vérité
    return session
  }
}

// ─── Contrôle d'accès ─────────────────────────────────────────────
export function checkAccess(user) {
  if (!user) return { hasAccess: false, reason: 'not_logged_in' }

  if (user.plan === 'subscription' && user.subscription_end) {
    const end = new Date(user.subscription_end)
    if (end > new Date()) return { hasAccess: true, reason: 'subscription' }
    const updated = { ...user, plan: 'free', subscription_end: null }
    setSession(updated)
  }

  if (Number(user.credits) > 0) return { hasAccess: true, reason: 'credits' }
  if (!user.free_used)          return { hasAccess: true, reason: 'free' }

  return { hasAccess: false, reason: 'no_access' }
}

// ─── Consommer 1 accès ────────────────────────────────────────────
export async function consumeAccess(user) {
  if (!user?.id) return user
  if (user.plan === 'subscription') return user

  try {
    if (Number(user.credits) > 0) {
      const newCredits = Number(user.credits) - 1
      await updateUser(user.id, { credits: newCredits })
      const updated = { ...user, credits: newCredits }
      setSession(updated)
      return updated
    }
    if (!user.free_used) {
      await updateUser(user.id, { free_used: true })
      const updated = { ...user, free_used: true }
      setSession(updated)
      return updated
    }
  } catch (e) {
    console.warn('consumeAccess fallback local:', e.message)
    const updated = user.credits > 0
      ? { ...user, credits: user.credits - 1 }
      : { ...user, free_used: true }
    setSession(updated)
    return updated
  }

  return user
}
