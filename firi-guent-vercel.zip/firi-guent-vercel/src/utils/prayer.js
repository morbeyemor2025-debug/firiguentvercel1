// Prayer calculator — supports Dakar (lat 14.7167, lng -17.4677) + any location
// Method: MWL (Muslim World League) — Fajr 18°, Isha 17°

function toRad(d)  { return d * Math.PI / 180 }
function toDeg(r)  { return r * 180 / Math.PI }
function fixH(h)   { return h - 24 * Math.floor(h / 24) }
function fixA(a)   { return a - 360 * Math.floor(a / 360) }

function julianDate(y, m, d) {
  if (m <= 2) { y--; m += 12 }
  const A = Math.floor(y / 100)
  const B = 2 - A + Math.floor(A / 4)
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5
}

function sunPos(jd) {
  const D = jd - 2451545
  const g = fixA(357.529 + 0.98560028 * D)
  const q = fixA(280.459 + 0.98564736 * D)
  const L = fixA(q + 1.915 * Math.sin(toRad(g)) + 0.020 * Math.sin(toRad(2 * g)))
  const e = 23.439 - 0.00000036 * D
  const RA = toDeg(Math.atan2(Math.cos(toRad(e)) * Math.sin(toRad(L)), Math.cos(toRad(L)))) / 15
  const decl = toDeg(Math.asin(Math.sin(toRad(e)) * Math.sin(toRad(L))))
  const EqT = q / 15 - fixH(RA)
  return { decl, EqT }
}

function computePrayers(lat, lng, timezone, date) {
  const y = date.getFullYear(), m = date.getMonth() + 1, d = date.getDate()
  const jd = julianDate(y, m, d) - lng / (15 * 24)
  const { decl, EqT } = sunPos(jd)
  const noon = 12 - lng / 15 - EqT + timezone

  function timeAngle(angle) {
    const val = -Math.sin(toRad(angle)) - Math.sin(toRad(lat)) * Math.sin(toRad(decl))
    const div = Math.cos(toRad(lat)) * Math.cos(toRad(decl))
    if (Math.abs(val / div) > 1) return null
    return toDeg(Math.acos(val / div)) / 15
  }

  const asrAngle = () => {
    const a = toDeg(Math.atan(1 / (1 + Math.tan(toRad(Math.abs(lat - decl))))))
    return timeAngle(90 - a)
  }

  const fmt = (h) => {
    if (h == null) return '--:--'
    const t = h % 24, hh = Math.floor(t), mm = Math.round((t - hh) * 60)
    return `${String(hh).padStart(2,'0')}:${String(mm < 60 ? mm : 59).padStart(2,'0')}`
  }

  const fO = timeAngle(18), sO = timeAngle(0.833), iO = timeAngle(17), aO = asrAngle()
  const fH = fO ? noon - fO : null
  const sH = sO ? noon - sO : null
  const aH = aO ? noon + aO : null
  const mH = sH ? noon + (noon - sH) : null
  const iH = iO ? noon + iO : null

  return [
    { key:'fajr',    ar:'الفجر',  phonetic:'Fajr',    fr:"Prière de l'aube",       time:fmt(fH),  h:fH },
    { key:'sunrise', ar:'الشروق', phonetic:'Shurûq',  fr:'Lever du soleil',         time:fmt(sH),  h:sH },
    { key:'dhuhr',   ar:'الظهر',  phonetic:'Dhuhr',   fr:'Prière de midi',          time:fmt(noon),h:noon },
    { key:'asr',     ar:'العصر',  phonetic:'Asr',     fr:"Prière de l'après-midi",  time:fmt(aH),  h:aH },
    { key:'maghrib', ar:'المغرب', phonetic:'Maghrib', fr:'Prière du coucher',       time:fmt(mH),  h:mH },
    { key:'isha',    ar:'العشاء', phonetic:'Isha',    fr:'Prière du soir',          time:fmt(iH),  h:iH },
  ]
}

// Dakar, Sénégal — UTC+0
export function getPrayerTimesDakar(date = new Date()) {
  return computePrayers(14.7167, -17.4677, 0, date)
}

// International — uses Intl API to get timezone offset
export function getPrayerTimesLocal(date = new Date()) {
  try {
    const offset = -date.getTimezoneOffset() / 60
    // Approximate location using timezone (not precise, requires geolocation for accuracy)
    // Default to Paris (Europe/Paris) as fallback for international
    return computePrayers(48.8566, 2.3522, offset, date)
  } catch {
    return getPrayerTimesDakar(date)
  }
}

// Generic — pass lat/lng/timezone
export function getPrayerTimesFor(lat, lng, timezone, date = new Date()) {
  return computePrayers(lat, lng, timezone, date)
}

export function getActivePrayer(prayers) {
  const now = new Date()
  const cur = now.getHours() + now.getMinutes() / 60
  const valid = prayers.filter(p => p.key !== 'sunrise' && p.h != null)
  let active = valid[valid.length - 1]
  for (const p of valid) { if (p.h != null && cur >= p.h) active = p }
  return active?.key
}

export function getNextPrayer(prayers) {
  const now = new Date()
  const cur = now.getHours() + now.getMinutes() / 60
  const valid = prayers.filter(p => p.key !== 'sunrise' && p.h != null)
  for (const p of valid) {
    if (p.h != null && p.h > cur) {
      const diff = Math.round((p.h - cur) * 60)
      const h = Math.floor(diff / 60), m = diff % 60
      return { ...p, countdown: h > 0 ? `${h}h ${m}min` : `${m} min` }
    }
  }
  const fajr = valid[0]
  if (fajr) {
    const diff = Math.round((24 - cur + fajr.h) * 60)
    const h = Math.floor(diff / 60), m = diff % 60
    return { ...fajr, countdown: `${h}h ${m}min` }
  }
  return null
}
