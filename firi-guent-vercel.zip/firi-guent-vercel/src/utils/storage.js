// localStorage helpers (fallback local pour rêves uniquement)
const K_DREAMS = 'fg14_dreams'

function safe(fn, fb) { try { return fn() } catch { return fb } }

export function genDreamId() {
  const c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  return 'FG-' + Array.from({length:5}, () => c[Math.floor(Math.random()*c.length)]).join('')
}

export const getDreams  = ()  => safe(() => JSON.parse(localStorage.getItem(K_DREAMS) || '[]'), [])
export const saveDream  = (d) => safe(() => localStorage.setItem(K_DREAMS, JSON.stringify([d, ...getDreams()].slice(0,100))))
export const deleteDream= (id)=> safe(() => localStorage.setItem(K_DREAMS, JSON.stringify(getDreams().filter(d=>d.id!==id))))

export function fmtDate(iso) {
  try { return new Date(iso).toLocaleDateString('fr-FR',{day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'}) }
  catch { return iso }
}

export function exportDreamsCSV() {
  const d = getDreams()
  if (!d.length) return ''
  return ['ID,Rêve,Date', ...d.map(x=>[x.dreamId||'', (x.text||'').replace(/,/g,' ').slice(0,100), x.date||''].join(','))].join('\n')
}

// ─── Lead management (kept for LeadCapture compatibility) ─────────
export function saveLead(lead) {
  try {
    const KEY = 'fg14_leads'
    const existing = JSON.parse(localStorage.getItem(KEY) || '[]')
    const filtered = existing.filter(l => l.email !== lead.email && l.phone !== lead.phone)
    localStorage.setItem(KEY, JSON.stringify([{ ...lead, savedAt: new Date().toISOString() }, ...filtered].slice(0, 200)))
  } catch {}
}

export function getLeads() {
  try { return JSON.parse(localStorage.getItem('fg14_leads') || '[]') } catch { return [] }
}
