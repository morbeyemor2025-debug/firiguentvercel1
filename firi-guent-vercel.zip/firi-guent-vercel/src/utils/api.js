// ─── api.js v21 — SÉCURISÉ ───────────────────────────────────────
// P0 : Plus d'appel direct à api.anthropic.com depuis le navigateur.
// Tous les appels passent par /.netlify/functions/interpret
// La clé Anthropic est uniquement dans les env vars Netlify.

import { API_INTERPRET } from './constants.js'

export async function analyzeDream({ text, emotion, time, name }, premium = false) {
  const res = await fetch(API_INTERPRET, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text, emotion, time, name, premium }),
  })

  if (!res.ok) {
    const e = await res.json().catch(() => ({}))
    throw new Error(e?.error ?? `Erreur consultation (${res.status})`)
  }

  const data = await res.json()
  if (!data.text) throw new Error('Réponse vide. Veuillez réessayer.')
  return data
}

// Génère uniquement le hook/teaser pour le paywall (P2)
export async function generatePaywallHook({ text, emotion, time }) {
  try {
    const res = await fetch(API_INTERPRET, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, emotion, time, hookOnly: true }),
    })
    if (!res.ok) return null
    const data = await res.json()
    return data.text || null
  } catch {
    return null
  }
}
