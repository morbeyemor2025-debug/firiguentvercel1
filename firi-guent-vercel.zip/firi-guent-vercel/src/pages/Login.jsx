// ─── Login.jsx v15 — REBUILD COMPLET ─────────────────────────────
// BUGS CORRIGÉS :
// 1. ✅ Message d'erreur 404 supprimé (c'était lié au mauvais BASE ID)
// 2. ✅ Tous les messages d'erreur Airtable affichés clairement
// 3. ✅ Redirection après login vers /interpreter

import React, { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { Mail, Phone, ArrowRight, Loader, AlertCircle, CheckCircle } from 'lucide-react'
import { loginOrRegister } from '../utils/auth.js'
import { useAuth } from '../utils/AuthContext.jsx'

export default function Login() {
  const [email,   setEmail]   = useState('')
  const [phone,   setPhone]   = useState('')
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState('')
  const [step,    setStep]    = useState('form')  // 'form' | 'loading' | 'done'
  const { setUser, user }     = useAuth()
  const navigate              = useNavigate()

  // Si déjà connecté → rediriger
  useEffect(() => {
    if (user) navigate('/interpreter', { replace: true })
  }, [user])

  const isValid = email.includes('@') && email.includes('.')

  const submit = async () => {
    if (!isValid) { setError('Entrez un email valide (ex: nom@gmail.com)'); return }
    setLoading(true)
    setError('')
    setStep('loading')

    try {
      const usr = await loginOrRegister(email.trim().toLowerCase(), phone.trim())
      setUser(usr)
      setStep('done')
      setTimeout(() => navigate('/interpreter'), 800)
    } catch (e) {
      setStep('form')
      // BUG CORRIGÉ : on affiche le vrai message Airtable, plus de faux 404
      const msg = e.message || ''
      if (msg.includes('Connexion impossible') || msg.includes('fetch')) {
        setError('Impossible de joindre le serveur. Vérifiez votre connexion internet.')
      } else if (msg.includes('401') || msg.includes('AUTHENTICATION')) {
        setError('Token Airtable invalide. Contactez le support.')
      } else if (msg.includes('403') || msg.includes('FORBIDDEN')) {
        setError('Accès refusé à Airtable. Vérifiez les permissions du token.')
      } else if (msg.includes('404') || msg.includes('TABLE_NOT_FOUND') || msg.includes('Could not find')) {
        setError('Table USERS introuvable. Créez-la dans Airtable (voir guide de configuration).')
      } else if (msg.includes('422') || msg.includes('INVALID') || msg.includes('UNKNOWN_FIELD')) {
        setError('Champ invalide dans Airtable. Vérifiez que tous les champs existent : email, phone, plan, credits, free_used.')
      } else {
        setError(msg || 'Une erreur est survenue. Réessayez dans quelques secondes.')
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ minHeight:'100vh', background:'var(--bg-hero)', display:'flex', alignItems:'center', justifyContent:'center', padding:16 }}>
      <div style={{ width:'100%', maxWidth:420 }}>

        {/* Logo & titre */}
        <div style={{ textAlign:'center', marginBottom:28 }}>
          <div style={{ fontSize:52, marginBottom:10, filter:'drop-shadow(0 0 16px rgba(110,231,183,.4))' }}>🌙</div>
          <h1 style={{ fontFamily:"'Amiri',serif", fontSize:'2rem', fontWeight:700, color:'#F9FAFB', marginBottom:4 }}>
            Firi Guent
          </h1>
          <div style={{ fontFamily:"'Scheherazade New',serif", fontSize:'1.1rem', color:'#6EE7B7', direction:'rtl', marginBottom:4 }}>
            تفسير الأحلام الإسلامي
          </div>
          <p style={{ color:'#9CA3AF', fontSize:13 }}>Ibn Sirin · Al-Nabulsi · Dakar 🇸🇳</p>
        </div>

        {/* Card */}
        <div style={{ background:'#fff', borderRadius:20, padding:'28px 24px', boxShadow:'0 20px 60px rgba(0,0,0,.3)' }}>

          {step === 'done' ? (
            <div style={{ textAlign:'center', padding:'20px 0' }}>
              <CheckCircle size={40} style={{ color:'var(--green)', margin:'0 auto 12px', display:'block' }}/>
              <div style={{ fontFamily:"'Amiri',serif", fontSize:'1.3rem', fontWeight:700, color:'var(--text)', marginBottom:6 }}>
                Bienvenue ! 🤲
              </div>
              <p style={{ color:'var(--text-muted)', fontSize:13 }}>Redirection en cours…</p>
            </div>
          ) : (
            <>
              <h2 style={{ fontFamily:"'Amiri',serif", fontSize:'1.4rem', fontWeight:700, color:'var(--text)', marginBottom:6, textAlign:'center' }}>
                Connexion / Inscription
              </h2>
              <p style={{ color:'var(--text-muted)', fontSize:12, textAlign:'center', marginBottom:20, lineHeight:1.6 }}>
                Entrez votre email pour accéder à votre compte.<br/>
                <strong style={{ color:'var(--green)' }}>1 interprétation gratuite</strong> offerte à l'inscription.
              </p>

              {/* Email */}
              <div style={{ marginBottom:12 }}>
                <label style={{ fontSize:13, fontWeight:600, color:'var(--text-2)', display:'block', marginBottom:5 }}>
                  Email *
                </label>
                <div style={{ position:'relative' }}>
                  <Mail size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'var(--text-muted)', pointerEvents:'none' }}/>
                  <input
                    type="email"
                    value={email}
                    onChange={e => { setEmail(e.target.value); setError('') }}
                    onKeyDown={e => e.key === 'Enter' && submit()}
                    className="field"
                    style={{ paddingLeft:34 }}
                    placeholder="votre@email.com"
                    autoFocus
                    disabled={loading}
                  />
                </div>
              </div>

              {/* WhatsApp */}
              <div style={{ marginBottom:18 }}>
                <label style={{ fontSize:13, fontWeight:600, color:'var(--text-2)', display:'block', marginBottom:5 }}>
                  WhatsApp{' '}
                  <span style={{ fontWeight:400, color:'var(--text-muted)' }}>(optionnel — pour recevoir vos analyses)</span>
                </label>
                <div style={{ position:'relative' }}>
                  <Phone size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'var(--text-muted)', pointerEvents:'none' }}/>
                  <input
                    type="tel"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && submit()}
                    className="field"
                    style={{ paddingLeft:34 }}
                    placeholder="+221 76 956 57 48"
                    disabled={loading}
                  />
                </div>
              </div>

              {/* Erreur */}
              {error && (
                <div style={{ display:'flex', alignItems:'flex-start', gap:8, padding:'10px 12px', background:'var(--error-bg)', border:'1px solid var(--error-border)', borderRadius:10, marginBottom:14, fontSize:12, color:'var(--error-text)', lineHeight:1.5 }}>
                  <AlertCircle size={14} style={{ flexShrink:0, marginTop:1 }}/>
                  <span>{error}</span>
                </div>
              )}

              {/* Bouton */}
              <button
                onClick={submit}
                disabled={loading || !isValid}
                className="btn btn-primary"
                style={{ width:'100%', padding:'14px', fontSize:15, borderRadius:12, fontFamily:"'Amiri',serif" }}
              >
                {loading
                  ? <><Loader size={16} style={{ animation:'spin .7s linear infinite' }}/> Connexion…</>
                  : <>Accéder à Firi Guent <ArrowRight size={16}/></>
                }
              </button>

              <p style={{ textAlign:'center', fontSize:11, color:'var(--text-muted)', marginTop:14, lineHeight:1.5 }}>
                🔒 Vos données sont confidentielles · Aucune carte requise<br/>
                Nouveau compte créé automatiquement si inexistant
              </p>
            </>
          )}
        </div>

        <div style={{ textAlign:'center', marginTop:16 }}>
          <Link to="/" style={{ color:'#6B7280', fontSize:12, textDecoration:'none' }}>
            ← Retour à l'accueil
          </Link>
        </div>
      </div>
    </div>
  )
}
