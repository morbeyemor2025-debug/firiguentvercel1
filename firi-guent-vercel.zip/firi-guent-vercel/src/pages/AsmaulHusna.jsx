import React, { useState, useMemo, useEffect } from 'react'
import { Search } from 'lucide-react'
import { ASMAUL_HUSNA } from '../utils/constants.js'

export default function AsmaulHusna() {
  const [query, setQuery] = useState('')

  // Scroll automatique en haut à l'ouverture de la page
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [])

  const filtered = useMemo(() => {
    const q = query.toLowerCase().trim()
    if (!q) return ASMAUL_HUSNA
    return ASMAUL_HUSNA.filter(n =>
      n.phonetic.toLowerCase().includes(q) ||
      n.fr.toLowerCase().includes(q) ||
      n.ar.includes(q)
    )
  }, [query])

  // Scroll en haut quand on clique sur un nom
  const handleClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <div className="min-h-screen pt-24 pb-16 px-4" style={{background:'var(--card)'}}>
      <div className="max-w-4xl mx-auto">

        {/* Header */}
        <div className="text-center mb-8">
          <div className="arabic-block inline-flex flex-col items-center px-8 py-4 mx-auto mb-4">
            <div className="arabic-script text-3xl">أَسْمَاءُ اللَّهِ الْحُسْنَى</div>
            <div className="arabic-phonetic text-base mt-1">Asmaul Husna</div>
            <div className="arabic-translation">Les 99 Noms les plus beaux d'Allah</div>
          </div>
          <p className="text-sm max-w-lg mx-auto" style={{color:'var(--text-3)'}}>
            Le Prophète ﷺ a dit : <em>"Allah a 99 noms — cent moins un. Quiconque les mémorise entrera au Paradis."</em>
          </p>
        </div>

        {/* Search */}
        <div className="relative mb-8 max-w-md mx-auto">
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2" style={{color:'var(--text-muted)'}}/>
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Rechercher un nom (ex: Rahman, Miséricordieux…)"
            className="field pl-10 w-full"
            style={{paddingLeft:40}}
          />
        </div>

        {/* Grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(min(100%, 200px), 1fr))',
          gap: 16
        }}>
          {filtered.map((name, i) => (
            <div
              key={i}
              onClick={handleClick}
              style={{
                background: '#fff',
                border: '1px solid var(--card-border)',
                borderRadius: 14,
                padding: '18px 14px',
                textAlign: 'center',
                cursor: 'pointer',
                transition: 'all .2s',
                boxShadow: '0 1px 8px rgba(0,0,0,.04)',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = 'var(--green)'
                e.currentTarget.style.boxShadow = '0 4px 16px rgba(6,95,70,.12)'
                e.currentTarget.style.transform = 'translateY(-2px)'
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = 'var(--card-border)'
                e.currentTarget.style.boxShadow = '0 1px 8px rgba(0,0,0,.04)'
                e.currentTarget.style.transform = 'none'
              }}
            >
              <div style={{
                fontFamily: "'Scheherazade New', serif",
                fontSize: '1.6rem',
                color: 'var(--green)',
                marginBottom: 6,
                lineHeight: 1.4,
                direction: 'rtl'
              }}>
                {name.ar}
              </div>
              <div style={{
                fontWeight: 700,
                fontSize: 13,
                color: 'var(--text)',
                marginBottom: 4
              }}>
                {name.phonetic}
              </div>
              <div style={{
                fontSize: 12,
                color: 'var(--text-muted)',
                lineHeight: 1.4
              }}>
                {name.fr}
              </div>
              <div style={{
                marginTop: 8,
                fontSize: 11,
                color: 'var(--text-muted)',
                opacity: 0.5
              }}>
                {i + 1}
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div style={{ textAlign:'center', padding:'48px 0', color:'var(--text-muted)' }}>
            Aucun nom trouvé pour "{query}"
          </div>
        )}

        {/* Footer */}
        <div className="arabic-block text-center mt-12 mx-auto" style={{maxWidth:400}}>
          <div className="arabic-script" style={{fontSize:'1.2rem'}}>
            سُبْحَانَهُ وَتَعَالَى
          </div>
          <div className="arabic-translation">Gloire à Lui, le Très-Haut</div>
        </div>
      </div>
    </div>
  )
}
