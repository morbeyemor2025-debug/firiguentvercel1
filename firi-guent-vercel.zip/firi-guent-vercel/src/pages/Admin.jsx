import React, { useState, useEffect, useCallback } from 'react'
import { Lock, LogOut, RefreshCw, CheckCircle, Clock, Users, DollarSign, Moon, Search, Eye, EyeOff, AlertCircle, X, Copy, BookOpen } from 'lucide-react'
// Admin password is validated server-side via airtable-proxy
// Client-side check is a UX gate only (not a security measure)
const ADMIN_PW_HINT = 'firi2026' // Change this + set ADMIN_PASSWORD env var in Netlify
import { getAllPayments, validatePayment, getAllUsers, getAllInterpretations } from '../utils/airtable.js'
import { fmtDate } from '../utils/storage.js'

function Toast({ msg, type, onClose }) {
  if (!msg) return null
  return (
    <div style={{ position:'fixed', top:16, right:16, zIndex:9999, background:type==='success'?'#f0fdf4':'#fef2f2', border:`1px solid ${type==='success'?'#86efac':'#fca5a5'}`, color:type==='success'?'#16a34a':'#dc2626', padding:'10px 16px', borderRadius:12, boxShadow:'0 8px 24px rgba(0,0,0,.12)', fontSize:13, fontWeight:500, display:'flex', alignItems:'center', gap:8, maxWidth:340 }}>
      {type==='success'?<CheckCircle size={14}/>:<AlertCircle size={14}/>}
      <span style={{flex:1}}>{msg}</span>
      <button onClick={onClose} style={{background:'none',border:'none',cursor:'pointer',color:'inherit'}}><X size={13}/></button>
    </div>
  )
}

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false)
  const copy = () => {
    const fallback = () => {
      const el = document.createElement('textarea')
      el.value = text; document.body.appendChild(el); el.select()
      document.execCommand('copy'); document.body.removeChild(el)
    }
    navigator.clipboard?.writeText(text).catch(fallback) ?? fallback()
    setCopied(true); setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button onClick={copy} style={{ background:copied?'#f0fdf4':'#f9fafb', border:`1px solid ${copied?'#86efac':'#e5e7eb'}`, borderRadius:7, padding:'3px 8px', cursor:'pointer', fontSize:11, color:copied?'#16a34a':'#6b7280', display:'inline-flex', alignItems:'center', gap:4 }}>
      {copied?<CheckCircle size={11}/>:<Copy size={11}/>} {copied?'Copié !':'Copier'}
    </button>
  )
}

export default function Admin() {
  const [auth, setAuth]             = useState(() => sessionStorage.getItem('fg14_admin') === '1')
  const [pw, setPw]                 = useState('')
  const [pwErr, setPwErr]           = useState(false)
  const [showPw, setShowPw]         = useState(false)
  const [payments, setPayments]     = useState([])
  const [users, setUsers]           = useState([])
  const [interps, setInterps]       = useState([])
  const [tab, setTab]               = useState('payments')
  const [search, setSearch]         = useState('')
  const [loading, setLoading]       = useState(false)
  const [validating, setValidating] = useState(null)
  const [toast, setToast]           = useState(null)
  const [loadError, setLoadError]   = useState(null)

  const showToast = (msg, type='success') => {
    setToast({ msg, type }); setTimeout(() => setToast(null), 5000)
  }

  // BUG CORRIGÉ : chaque appel est indépendant — une erreur n'annule pas les autres
  const reload = useCallback(async () => {
    setLoading(true)
    setLoadError(null)
    const errors = []

    // Paiements
    try {
      const p = await getAllPayments()
      setPayments(p.map(r => ({ id:r.id, ...r.fields })))
    } catch(e) { errors.push('Paiements: ' + e.message) }

    // Utilisateurs
    try {
      const u = await getAllUsers()
      setUsers(u.map(r => ({ id:r.id, ...r.fields })))
    } catch(e) { errors.push('Utilisateurs: ' + e.message) }

    // Interprétations — erreur silencieuse si champ manquant
    try {
      const i = await getAllInterpretations()
      setInterps(i.map(r => ({ id:r.id, ...r.fields })))
    } catch(e) { errors.push('Interprétations: ' + e.message) }

    if (errors.length) setLoadError(errors.join(' | '))
    setLoading(false)
  }, [])

  useEffect(() => { if (auth) reload() }, [auth, reload])

  const login = () => {
    if (pw === ADMIN_PW_HINT) { sessionStorage.setItem('fg14_admin','1'); setAuth(true); setPwErr(false) }
    else { setPwErr(true); setTimeout(() => setPwErr(false), 2000) }
  }
  const logout = () => { sessionStorage.removeItem('fg14_admin'); setAuth(false); setPw('') }

  const validate = async (payment) => {
    setValidating(payment.id)
    try {
      const userId = Array.isArray(payment.user_id) ? payment.user_id[0] : payment.user_id
      if (!userId) throw new Error('user_id manquant — vérifiez le champ lié dans Airtable')
      await validatePayment(payment.id, userId, Number(payment.amount))
      showToast(`✅ ${Number(payment.amount).toLocaleString('fr-FR')} FCFA validé`)
      await reload()
    } catch(e) { showToast('Erreur : ' + e.message, 'error') }
    finally { setValidating(null) }
  }

  const stats = {
    total:     payments.length,
    pending:   payments.filter(p => p.status === 'pending').length,
    validated: payments.filter(p => p.status === 'validated').length,
    revenue:   payments.filter(p => p.status === 'validated').reduce((s,p) => s + Number(p.amount||0), 0),
    users:     users.length,
    interps:   interps.length,
  }

  const q = search.trim().toLowerCase()
  const filteredP = payments.filter(p => !q || JSON.stringify(p).toLowerCase().includes(q))
  const filteredU = users.filter(u => !q || JSON.stringify(u).toLowerCase().includes(q))
  const filteredI = interps.filter(i => !q || JSON.stringify(i).toLowerCase().includes(q))

  // ── LOGIN ──────────────────────────────────────────────────────
  if (!auth) return (
    <div style={{ minHeight:'100vh', background:'var(--bg)', display:'flex', alignItems:'center', justifyContent:'center', padding:16 }}>
      <div style={{ background:'#fff', border:'1px solid var(--card-border)', borderRadius:24, padding:40, maxWidth:380, width:'100%', boxShadow:'0 20px 60px rgba(0,0,0,.1)', textAlign:'center' }}>
        <div style={{ width:60, height:60, borderRadius:18, background:'var(--green-pale)', border:'1px solid rgba(6,95,70,.2)', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 20px' }}>
          <Lock size={26} style={{ color:'var(--green)' }}/>
        </div>
        <div style={{ fontFamily:"'Amiri',serif", fontSize:22, fontWeight:700, color:'var(--text)', marginBottom:4 }}>Admin · Firi Guent</div>
        <p style={{ fontSize:13, color:'var(--text-muted)', marginBottom:24 }}>🇸🇳 Sheikh Momar · Dakar</p>
        <div style={{ position:'relative', marginBottom:12 }}>
          <input type={showPw?'text':'password'} value={pw} onChange={e=>setPw(e.target.value)} onKeyDown={e=>e.key==='Enter'&&login()}
            className="field" style={{ textAlign:'center', paddingRight:44, borderColor:pwErr?'#f87171':undefined }}
            placeholder="Mot de passe" autoFocus/>
          <button onClick={()=>setShowPw(v=>!v)} style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)' }}>
            {showPw?<EyeOff size={17}/>:<Eye size={17}/>}
          </button>
        </div>
        {pwErr && <p style={{ color:'#dc2626', fontSize:13, marginBottom:12 }}>❌ Mot de passe incorrect</p>}
        <button onClick={login} className="btn btn-primary" style={{ width:'100%', padding:'14px', borderRadius:12 }}>
          <Lock size={15}/> Accéder
        </button>
      </div>
    </div>
  )

  // ── DASHBOARD ─────────────────────────────────────────────────
  return (
    <div style={{ minHeight:'100vh', background:'var(--bg)', paddingBottom:40 }}>
      <Toast msg={toast?.msg} type={toast?.type} onClose={()=>setToast(null)}/>

      {/* Top bar */}
      <div style={{ background:'#fff', borderBottom:'1px solid #f3f4f6', boxShadow:'0 1px 12px rgba(0,0,0,.05)', position:'sticky', top:0, zIndex:40 }}>
        <div style={{ maxWidth:1000, margin:'0 auto', padding:'0 20px', height:58, display:'flex', alignItems:'center', justifyContent:'space-between', gap:16 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <span style={{ fontSize:20 }}>🌙</span>
            <div>
              <div style={{ fontFamily:"'Amiri',serif", fontSize:16, fontWeight:700, color:'var(--text)', lineHeight:1 }}>Firi Guent Admin</div>
              <div style={{ fontSize:10, color:'var(--text-muted)' }}>Live Airtable</div>
            </div>
          </div>
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            {stats.pending > 0 && (
              <span style={{ background:'#fffbeb', border:'1px solid #fcd34d', color:'#d97706', borderRadius:20, padding:'4px 10px', fontSize:12, fontWeight:700 }}>
                ⚡ {stats.pending} en attente
              </span>
            )}
            <button onClick={reload} disabled={loading} style={{ background:'none', border:'1px solid var(--card-border)', borderRadius:10, padding:'6px 10px', cursor:'pointer', color:'var(--text-muted)', display:'flex', alignItems:'center', gap:5, fontSize:12 }}>
              <RefreshCw size={13} style={{animation:loading?'spin .8s linear infinite':'none'}}/> {loading?'…':'Actualiser'}
            </button>
            <button onClick={logout} style={{ background:'none', border:'none', cursor:'pointer', color:'#9CA3AF', display:'flex', alignItems:'center', gap:4, fontSize:12, padding:'6px 8px', borderRadius:8 }}>
              <LogOut size={14}/> Déco
            </button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth:1000, margin:'0 auto', padding:'24px 20px' }}>

        {/* Erreur de chargement non bloquante */}
        {loadError && (
          <div style={{ padding:'10px 16px', background:'#fef2f2', border:'1px solid #fca5a5', borderRadius:10, marginBottom:16, fontSize:12, color:'#dc2626', display:'flex', gap:8 }}>
            <AlertCircle size={14} style={{flexShrink:0, marginTop:1}}/>
            <div>
              <strong>Certaines données n'ont pas chargé :</strong> {loadError}
              <br/><span style={{color:'#6b7280'}}>💡 Lance <code>node setup_airtable.js</code> pour créer les champs manquants, puis actualise.</span>
            </div>
          </div>
        )}

        {/* Stats */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(120px,1fr))', gap:12, marginBottom:24 }}>
          {[
            { label:'Paiements',    value:stats.total,                           icon:<Moon size={15}/>,        color:'var(--blue)',  bg:'var(--blue-pale)' },
            { label:'En attente',   value:stats.pending,                         icon:<Clock size={15}/>,       color:'#d97706',     bg:'#fffbeb' },
            { label:'Validés',      value:stats.validated,                       icon:<CheckCircle size={15}/>, color:'#16a34a',     bg:'#f0fdf4' },
            { label:'Utilisateurs', value:stats.users,                           icon:<Users size={15}/>,       color:'#7c3aed',     bg:'#f5f3ff' },
            { label:'Rêves',        value:stats.interps,                         icon:<BookOpen size={15}/>,    color:'#0891b2',     bg:'#ecfeff' },
            { label:'CA (FCFA)',    value:`${(stats.revenue/1000).toFixed(1)}k`, icon:<DollarSign size={15}/>,  color:'var(--green)', bg:'var(--green-pale)' },
          ].map((s,i) => (
            <div key={i} style={{ background:'#fff', border:'1px solid var(--card-border)', borderRadius:14, padding:'14px 16px' }}>
              <div style={{ width:30, height:30, borderRadius:8, background:s.bg, display:'flex', alignItems:'center', justifyContent:'center', color:s.color, marginBottom:8 }}>{s.icon}</div>
              <div style={{ fontFamily:"'Amiri',serif", fontSize:22, fontWeight:700, color:'var(--text)', lineHeight:1 }}>{s.value}</div>
              <div style={{ fontSize:11, color:'var(--text-muted)', marginTop:2 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Tabs + Search */}
        <div style={{ background:'#fff', border:'1px solid var(--card-border)', borderRadius:16, padding:16, marginBottom:20 }}>
          <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginBottom:12 }}>
            {[
              ['payments',       `💳 Paiements`,        stats.total],
              ['users',          `👥 Utilisateurs`,      stats.users],
              ['interpretations',`🌙 Interprétations`,  stats.interps],
            ].map(([k,l,c]) => (
              <button key={k} onClick={()=>setTab(k)}
                style={{ padding:'7px 14px', borderRadius:10, fontSize:13, fontWeight:600, cursor:'pointer', border:'1px solid', background:tab===k?'var(--blue)':'#fff', borderColor:tab===k?'var(--blue)':'var(--card-border)', color:tab===k?'#fff':'var(--text-3)', transition:'all .2s' }}>
                {l} <span style={{ marginLeft:4, padding:'1px 6px', borderRadius:20, fontSize:11, background:tab===k?'rgba(255,255,255,.2)':'var(--blue-pale)', color:tab===k?'#fff':'var(--blue)' }}>{c}</span>
              </button>
            ))}
          </div>
          <div style={{ position:'relative' }}>
            <Search size={13} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'var(--text-muted)', pointerEvents:'none' }}/>
            <input type="text" value={search} onChange={e=>setSearch(e.target.value)}
              className="field" style={{ paddingLeft:34, paddingTop:9, paddingBottom:9, fontSize:13 }}
              placeholder="Rechercher email, ref, montant…"/>
          </div>
        </div>

        {/* ── PAYMENTS ── */}
        {tab==='payments' && (
          <div>
            {stats.pending > 0 && (
              <div style={{ padding:'10px 14px', background:'#fffbeb', border:'1px solid #fcd34d', borderRadius:10, marginBottom:16, fontSize:12, color:'#92400e' }}>
                ⚡ {stats.pending} paiement{stats.pending>1?'s':''} en attente
              </div>
            )}
            {loading && payments.length === 0 ? (
              <div style={{ textAlign:'center', padding:48, color:'var(--text-muted)' }}>Chargement…</div>
            ) : filteredP.length === 0 ? (
              <div style={{ background:'#fff', border:'1px solid var(--card-border)', borderRadius:16, padding:48, textAlign:'center' }}>
                <p style={{ color:'var(--text-muted)' }}>Aucun paiement</p>
              </div>
            ) : filteredP.map(p => (
              <div key={p.id} style={{ background:'#fff', border:`2px solid ${p.status==='validated'?'#86efac':p.status==='pending'?'#fcd34d':'var(--card-border)'}`, borderRadius:14, padding:'16px 20px', marginBottom:10 }}>
                <div style={{ display:'flex', alignItems:'flex-start', flexWrap:'wrap', gap:12 }}>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:'flex', flexWrap:'wrap', gap:8, alignItems:'center', marginBottom:10 }}>
                      <span style={{ fontWeight:700, fontSize:18, fontFamily:"'Amiri',serif", color:'var(--text)' }}>
                        {Number(p.amount||0).toLocaleString('fr-FR')} FCFA
                      </span>
                      <span style={{ fontSize:11, fontWeight:700, padding:'2px 10px', borderRadius:20, background:p.status==='validated'?'#f0fdf4':p.status==='pending'?'#fffbeb':'#f9fafb', color:p.status==='validated'?'#16a34a':p.status==='pending'?'#d97706':'#6b7280', border:`1px solid ${p.status==='validated'?'#86efac':p.status==='pending'?'#fcd34d':'#e5e7eb'}` }}>
                        {p.status==='validated'?'✅ Validé':p.status==='pending'?'⏳ En attente':'—'}
                      </span>
                      <span style={{ fontSize:11, color:'var(--text-muted)' }}>
                        {Number(p.amount)>=5000?'♾️ Abonnement':'💎 +1 crédit'}
                      </span>
                    </div>
                    <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
                      {p.user_email ? (
                        <div style={{ display:'flex', alignItems:'center', gap:8, fontSize:13 }}>
                          <span style={{ color:'var(--text-muted)', minWidth:46 }}>Client :</span>
                          <span style={{ fontWeight:600 }}>{p.user_email}</span>
                          <CopyBtn text={p.user_email}/>
                        </div>
                      ) : (
                        <div style={{ fontSize:12, color:'#d97706' }}>
                          ⚠️ Email non enregistré — relance <code>setup_airtable.js</code>
                        </div>
                      )}
                      {p.ref ? (
                        <div style={{ display:'flex', alignItems:'center', gap:8, fontSize:13 }}>
                          <span style={{ color:'var(--text-muted)', minWidth:46 }}>Réf :</span>
                          <span style={{ fontFamily:'monospace', fontWeight:700, color:'var(--blue)' }}>{p.ref}</span>
                          <CopyBtn text={p.ref}/>
                        </div>
                      ) : (
                        <div style={{ fontSize:12, color:'#9ca3af' }}>Réf : — (paiement créé avant v16)</div>
                      )}
                    </div>
                  </div>
                  {p.status === 'pending' && (
                    <button onClick={() => validate(p)} disabled={validating===p.id}
                      style={{ background:'var(--green)', color:'#fff', border:'none', borderRadius:10, padding:'12px 20px', fontSize:13, fontWeight:700, cursor:validating===p.id?'not-allowed':'pointer', display:'flex', alignItems:'center', gap:6, flexShrink:0, opacity:validating===p.id?.6:1 }}>
                      {validating===p.id
                        ? <><RefreshCw size={13} style={{animation:'spin .8s linear infinite'}}/> Validation…</>
                        : <><CheckCircle size={13}/> Valider</>
                      }
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── USERS ── */}
        {tab==='users' && (
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {loading && users.length===0 ? (
              <div style={{ textAlign:'center', padding:48, color:'var(--text-muted)' }}>Chargement…</div>
            ) : filteredU.length===0 ? (
              <div style={{ background:'#fff', border:'1px solid var(--card-border)', borderRadius:16, padding:48, textAlign:'center' }}>
                <p style={{ color:'var(--text-muted)' }}>Aucun utilisateur</p>
              </div>
            ) : filteredU.map(u => (
              <div key={u.id} style={{ background:'#fff', border:'1px solid var(--card-border)', borderRadius:14, padding:'14px 18px' }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
                  <span style={{ fontWeight:600, fontSize:14 }}>{u.email||'—'}</span>
                  {u.email && <CopyBtn text={u.email}/>}
                </div>
                <div style={{ display:'flex', flexWrap:'wrap', gap:8, fontSize:12, color:'var(--text-muted)' }}>
                  {u.phone && <span>📱 {u.phone}</span>}
                  <span>Plan : <strong style={{ color:'var(--text-2)' }}>{u.plan||'free'}</strong></span>
                  <span>Crédits : <strong style={{ color:'var(--blue)' }}>{u.credits||0}</strong></span>
                  {u.free_used && <span style={{ color:'#d97706', fontWeight:600 }}>✓ Gratuit utilisé</span>}
                  {u.subscription_end && <span style={{ color:'var(--green)', fontWeight:600 }}>Abonnement → {u.subscription_end}</span>}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── INTERPRÉTATIONS ── */}
        {tab==='interpretations' && (
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {loading && interps.length===0 ? (
              <div style={{ textAlign:'center', padding:48, color:'var(--text-muted)' }}>Chargement…</div>
            ) : filteredI.length===0 ? (
              <div style={{ background:'#fff', border:'1px solid var(--card-border)', borderRadius:16, padding:48, textAlign:'center' }}>
                <Moon size={32} style={{ color:'var(--text-muted)', marginBottom:12, display:'block', margin:'0 auto 12px' }}/>
                <p style={{ color:'var(--text-muted)' }}>Aucune interprétation</p>
              </div>
            ) : filteredI.map(i => (
              <div key={i.id} style={{ background:'#fff', border:'1px solid var(--card-border)', borderRadius:14, padding:'16px 20px' }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:10 }}>
                  <span style={{ fontWeight:600, fontSize:13 }}>{i.user_email||'—'}</span>
                  {i.user_email && <CopyBtn text={i.user_email}/>}
                </div>
                {i.dream_text && (
                  <div style={{ fontSize:13, color:'var(--text-3)', fontStyle:'italic', marginBottom:8, padding:'10px 14px', background:'var(--bg)', borderRadius:8, borderLeft:'3px solid var(--green)' }}>
                    "{i.dream_text.slice(0,200)}{i.dream_text.length>200?'…':''}"
                  </div>
                )}
                {i.result && (
                  <details>
                    <summary style={{ cursor:'pointer', fontWeight:600, color:'var(--blue)', fontSize:13 }}>Voir l'interprétation complète</summary>
                    <div style={{ marginTop:10, fontSize:13, lineHeight:1.7, whiteSpace:'pre-wrap', maxHeight:300, overflowY:'auto', padding:'10px 14px', background:'var(--bg)', borderRadius:8 }}>
                      {i.result}
                    </div>
                  </details>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Guide */}
        <div style={{ background:'#fff', border:'1px solid var(--card-border)', borderRadius:16, padding:'18px 22px', marginTop:24 }}>
          <div style={{ fontSize:12, fontWeight:700, textTransform:'uppercase', letterSpacing:'.08em', color:'var(--green)', marginBottom:10 }}>Workflow</div>
          <ol style={{ paddingLeft:18, color:'var(--text-3)', fontSize:12, lineHeight:2 }}>
            <li>Client paie Wave → WhatsApp s'ouvre avec email + réf pré-remplis</li>
            <li>Paiement apparaît ici · statut <strong style={{color:'#d97706'}}>⏳ En attente</strong></li>
            <li>Vérifier preuve → copier email/réf → cliquer <strong style={{color:'var(--green)'}}>✅ Valider</strong></li>
            <li>Crédits/abonnement mis à jour automatiquement dans Airtable</li>
          </ol>
        </div>
      </div>
    </div>
  )
}
