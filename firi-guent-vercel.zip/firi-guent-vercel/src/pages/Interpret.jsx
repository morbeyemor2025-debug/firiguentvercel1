// ─── Interpret.jsx v21 ───────────────────────────────────────────
// P1 : Auth en cours de formulaire (step 3→4), pas à l'entrée
// P2 : Résultat gratuit tronqué + hook IA personnalisé basé sur le vrai rêve
// P3 : Paiement Wave direct (lien pay.wave.com)

import React, { useState, useCallback, useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { ChevronRight, ChevronLeft, Moon, AlertCircle, CheckCircle } from 'lucide-react'
import { EMOTIONS, TIMES, PACKS, WAVE_PAY_BASE, waExpertLink } from '../utils/constants.js'
import { analyzeDream, generatePaywallHook } from '../utils/api.js'
import { genDreamId, saveDream } from '../utils/storage.js'
import { saveInterpretation, createPayment } from '../utils/airtable.js'
import { checkAccess, consumeAccess } from '../utils/auth.js'
import { useAuth } from '../utils/AuthContext.jsx'
import ResultView from '../components/ResultView.jsx'

const TOTAL = 4

// ─── Wave Payment Button (P3) ─────────────────────────────────────
// Lien Wave direct : https://pay.wave.com/m/M_sn_RbUCLj3KcUQh/c/sn/
// Paramètre amount en FCFA selon la doc Wave
function waveDirectLink(pack) {
  // Le lien Wave accepte un paramètre amount optionnel
  // Format : https://pay.wave.com/m/{merchant_id}/c/sn/?amount={amount}
  const amount = pack.price
  return `${WAVE_PAY_BASE}?amount=${amount}`
}

const WaIcon = ({ size=16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.127.558 4.126 1.533 5.859L.057 23.62a.5.5 0 00.598.65l5.956-1.558A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22a9.944 9.944 0 01-5.13-1.415l-.363-.217-3.773.987.997-3.676-.237-.378A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
  </svg>
)

const WaveIcon = ({ size=18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z"/>
  </svg>
)

// ─── P3 : Paywall avec Wave direct ───────────────────────────────
function Paywall({ user, dreamId, hookText, form }) {
  const [paidPack, setPaidPack] = useState(null)

  const handleWaveClick = async (pack) => {
    setPaidPack(pack)
    // Enregistrer la tentative de paiement dans Airtable (silencieux)
    if (user?.id) {
      try { await createPayment(user.id, pack.price, user.email || '', dreamId || '') } catch {}
    }
  }

  return (
    <div style={{ padding:'32px 24px', textAlign:'center' }}>
      <div style={{ fontSize:52, marginBottom:16 }}>🔒</div>
      <h2 style={{ fontFamily:"'Amiri',serif", fontSize:'1.8rem', fontWeight:700, color:'var(--text)', marginBottom:8 }}>
        Votre interprétation gratuite<br/>a été utilisée
      </h2>

      {/* P2 : Hook IA personnalisé basé sur le vrai rêve */}
      {hookText && (
        <div style={{ margin:'0 0 20px', padding:'14px 18px', background:'var(--gold-pale)', border:'1px solid #FDE68A', borderRadius:12, textAlign:'left', fontSize:14, color:'var(--text-2)', lineHeight:1.7, fontStyle:'italic' }}>
          <span style={{ fontSize:16, marginRight:6 }}>✨</span>
          {hookText}
        </div>
      )}

      <p style={{ color:'var(--text-3)', marginBottom:6, fontSize:'1rem' }}>Choisissez un pack pour accéder à l'analyse complète.</p>
      <p style={{ color:'var(--text-muted)', fontSize:13, marginBottom:24 }}>
        Paiement Wave sécurisé · Accès immédiat · <em style={{color:'var(--gold)'}}>In sha Allah</em>
      </p>

      {/* P3 : Boutons Wave directs */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(190px,1fr))', gap:14, marginBottom:24 }}>
        {PACKS.map(pack => (
          <div key={pack.id} style={{
            border: pack.popular ? '2.5px solid var(--blue)' : '1.5px solid var(--card-border)',
            borderRadius:16, padding:'22px 16px', position:'relative',
            background: pack.popular ? 'var(--blue-pale)' : 'var(--card)'
          }}>
            {pack.popular && (
              <div style={{ position:'absolute', top:-12, left:'50%', transform:'translateX(-50%)', background:'var(--blue)', color:'#fff', borderRadius:20, padding:'3px 12px', fontSize:11, fontWeight:700, whiteSpace:'nowrap' }}>
                ⭐ Meilleur rapport
              </div>
            )}
            <div style={{ fontFamily:"'Amiri',serif", fontSize:30, fontWeight:700, color: pack.popular ? 'var(--blue)' : 'var(--text)', lineHeight:1 }}>
              {pack.fcfa.replace(' FCFA','')}
            </div>
            <div style={{ fontSize:12, color:'var(--text-muted)', marginBottom:4 }}>FCFA</div>
            <div style={{ fontWeight:600, color:'var(--text-2)', marginBottom:4, fontSize:13 }}>{pack.label}</div>
            <div style={{ fontSize:11, color:'var(--text-muted)', marginBottom:14 }}>
              {pack.subscription ? 'Illimité 30 jours' : `${Math.round(pack.price/pack.credits)} FCFA/rêve`}
            </div>

            {/* Bouton Wave direct (P3) */}
            <a
              href={waveDirectLink(pack)}
              target="_blank"
              rel="noreferrer"
              onClick={() => handleWaveClick(pack)}
              style={{
                display:'flex', alignItems:'center', justifyContent:'center', gap:6,
                width:'100%', padding:'11px', borderRadius:10, fontSize:13, fontWeight:700,
                textDecoration:'none', cursor:'pointer', transition:'all .18s',
                background: pack.popular ? '#1B5EE5' : 'var(--bg)',
                color: pack.popular ? '#fff' : 'var(--blue)',
                border: pack.popular ? 'none' : '2px solid var(--blue)',
              }}
            >
              <svg width="16" height="16" viewBox="0 0 40 40" fill="currentColor">
                <circle cx="20" cy="20" r="20" fill={pack.popular ? 'rgba(255,255,255,0.2)' : 'transparent'}/>
                <text x="20" y="26" textAnchor="middle" fontSize="18" fontWeight="bold" fill="currentColor">W</text>
              </svg>
              Payer {pack.fcfa}
            </a>
          </div>
        ))}
      </div>

      {/* Confirmation post-clic */}
      {paidPack && (
        <div style={{ padding:'16px', background:'var(--green-pale)', border:'1px solid #A7F3D0', borderRadius:12, fontSize:13, color:'var(--text-2)', textAlign:'left', marginBottom:16 }}>
          <strong>✅ Wave ouvert — {paidPack.label}</strong>
          <p style={{ margin:'8px 0 0', lineHeight:1.7 }}>
            Complétez le paiement de <strong>{paidPack.fcfa}</strong> dans Wave.<br/>
            Vos crédits seront ajoutés automatiquement. <em style={{color:'var(--gold)'}}>In sha Allah</em>
          </p>
        </div>
      )}

      <div style={{ padding:'16px', background:'var(--info-bg)', border:'1px solid var(--info-border)', borderRadius:12, fontSize:13, color:'var(--info-text)', textAlign:'left' }}>
        <strong>🔐 Paiement sécurisé Wave</strong>
        <ol style={{ paddingLeft:18, marginTop:8, lineHeight:1.8 }}>
          <li>Cliquez sur votre pack → Wave s'ouvre</li>
          <li>Confirmez le paiement dans Wave</li>
          <li>Vos crédits sont ajoutés automatiquement</li>
          <li>Revenez ici pour débloquer votre interprétation complète</li>
        </ol>
      </div>
    </div>
  )
}

// ─── Step 3.5 : Capture email en douceur (P1) ────────────────────
function EmailGate({ onSubmit, loading, error }) {
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const isValid = email.includes('@') && email.includes('.')

  return (
    <div className="card p-6 up">
      <div style={{ textAlign:'center', marginBottom:20 }}>
        <div style={{ fontSize:36, marginBottom:8 }}>🌙</div>
        <h2 style={{ fontFamily:"'Amiri',serif", fontSize:'1.4rem', fontWeight:700, color:'var(--text)', marginBottom:8 }}>
          Presque prêt…
        </h2>
        <p style={{ color:'var(--text-muted)', fontSize:13, lineHeight:1.6 }}>
          Votre interprétation est prête.<br/>
          Entrez votre email pour la recevoir gratuitement.
        </p>
      </div>

      <div style={{ display:'flex', flexDirection:'column', gap:12, marginBottom:16 }}>
        <input
          type="email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          placeholder="votre@email.com"
          className="field"
          autoFocus
          style={{ padding:'14px', fontSize:15 }}
        />
        <input
          type="tel"
          value={phone}
          onChange={e => setPhone(e.target.value)}
          placeholder="Téléphone (optionnel)"
          className="field"
          style={{ padding:'14px', fontSize:15 }}
        />
      </div>

      {error && (
        <div style={{ display:'flex', alignItems:'flex-start', gap:8, padding:'10px 14px', background:'var(--error-bg)', border:'1px solid var(--error-border)', borderRadius:10, marginBottom:14, fontSize:13, color:'var(--error-text)' }}>
          <AlertCircle size={15} style={{ flexShrink:0, marginTop:1 }}/>{error}
        </div>
      )}

      <div style={{ padding:'10px 14px', background:'var(--green-pale)', border:'1px solid #A7F3D0', borderRadius:10, marginBottom:14, fontSize:12, color:'var(--text-3)' }}>
        🎁 <strong>1 interprétation gratuite</strong> offerte · Sheikh Momar · 420+ mots d'analyse
      </div>

      <button
        onClick={() => onSubmit(email.trim().toLowerCase(), phone.trim())}
        disabled={!isValid || loading}
        className="btn btn-primary"
        style={{ width:'100%', padding:'14px', fontSize:15, borderRadius:12 }}
      >
        {loading
          ? <><span className="spin" style={{ width:18, height:18, border:'2px solid rgba(255,255,255,.3)', borderTopColor:'#fff' }}/> Connexion…</>
          : <><Moon size={18}/> Voir mon interprétation</>
        }
      </button>

      <p style={{ textAlign:'center', fontSize:11, color:'var(--text-muted)', marginTop:10 }}>
        Pas de spam · Pas de mot de passe · In sha Allah
      </p>
    </div>
  )
}

export default function Interpret() {
  const { user, refresh, setUser } = useAuth()

  const [step, setStep]               = useState(1)
  const [form, setForm]               = useState({ text:'', emotion:'', time:'' })
  const [loading, setLoading]         = useState(false)
  const [authLoading, setAuthLoading] = useState(false)
  const [error, setError]             = useState(null)
  const [authError, setAuthError]     = useState(null)
  const [result, setResult]           = useState(null)
  const [dreamId, setDreamId]         = useState(null)
  const [showPaywall, setShowPaywall] = useState(false)
  const [hookText, setHookText]       = useState(null)
  // step 4.5 = EmailGate (P1)

  useEffect(() => {
    if (step === 5) return
    if (!user) return
    const access = checkAccess(user)
    setShowPaywall(!access.hasAccess)
  }, [user, step])

  const patch = (k, v) => setForm(f => ({ ...f, [k]: v }))
  const canGo = () => {
    if (step === 1) return form.text.trim().length >= 40
    if (step === 2) return form.emotion !== ''
    if (step === 3) return form.time !== ''
    return true
  }

  // P1 : Quand l'user clique "Continuer" depuis step 3
  // Si pas encore connecté → EmailGate (step 4.5)
  // Si déjà connecté → step 4 (confirmation)
  const goFromStep3 = () => {
    if (!user) {
      setStep('4.5') // EmailGate
    } else {
      setStep(4)
    }
  }

  // P1 : Soumission de l'email dans EmailGate
  const handleEmailSubmit = async (email, phone) => {
    if (!email || !email.includes('@')) {
      setAuthError('Email invalide.')
      return
    }
    setAuthLoading(true)
    setAuthError(null)
    try {
      const { loginOrRegister } = await import('../utils/auth.js')
      const usr = await loginOrRegister(email, phone)
      setUser(usr)
      setStep(4)
    } catch (e) {
      const msg = e.message || ''
      if (msg.includes('Connexion impossible') || msg.includes('fetch')) {
        setAuthError('Impossible de joindre le serveur. Vérifiez votre connexion.')
      } else if (msg.includes('401') || msg.includes('AUTHENTICATION')) {
        setAuthError('Token Airtable invalide. Contactez le support.')
      } else {
        setAuthError(msg || 'Une erreur est survenue. Réessayez.')
      }
    } finally {
      setAuthLoading(false)
    }
  }

  const access = checkAccess(user)

  const submit = useCallback(async () => {
    const freshAccess = checkAccess(user)
    if (!freshAccess.hasAccess) {
      // Générer le hook personnalisé en arrière-plan (P2)
      setShowPaywall(true)
      generatePaywallHook({ text:form.text, emotion:form.emotion, time:form.time })
        .then(hook => { if (hook) setHookText(hook) })
        .catch(() => {})
      return
    }

    setLoading(true); setError(null)
    try {
      const id  = genDreamId()
      const res = await analyzeDream({ text:form.text, emotion:form.emotion, time:form.time, name:user?.email }, false)

      setDreamId(id)
      setResult(res)
      setStep(5)

      consumeAccess(user).then(() => refresh()).catch(() => {})

      if (user?.id) saveInterpretation(user.id, form.text, res.text, user.email||'').catch(() => {})
      saveDream({ id:Date.now(), dreamId:id, date:new Date().toISOString(), ...form, result:res })

    } catch(e) {
      setError(e?.message ?? 'Une erreur est survenue. Vérifiez votre connexion.')
    } finally {
      setLoading(false)
    }
  }, [form, user, refresh])

  const restart = () => {
    setStep(1)
    setForm({ text:'', emotion:'', time:'' })
    setResult(null); setError(null); setDreamId(null); setHookText(null)
    if (user) setShowPaywall(!checkAccess(user).hasAccess)
  }

  const AccessBadge = () => {
    if (!user) return null
    if (access.reason === 'free')         return <div className="badge-green" style={{display:'inline-flex',marginBottom:12}}>🎁 1 interprétation gratuite disponible</div>
    if (access.reason === 'credits')      return <div className="badge-blue"  style={{display:'inline-flex',marginBottom:12}}>💎 {user.credits} crédit{user.credits>1?'s':''} disponible{user.credits>1?'s':''}</div>
    if (access.reason === 'subscription') return <div className="badge-green" style={{display:'inline-flex',marginBottom:12}}>♾️ Abonnement actif — illimité</div>
    return null
  }

  return (
    <div style={{ minHeight:'100vh', background:'var(--bg)', padding:'80px 16px 64px' }}>
      <div style={{ maxWidth:560, margin:'0 auto' }}>

        <div style={{ textAlign:'center', marginBottom:24 }}>
          <div className="label-sm mb-1" style={{ color:'var(--green)' }}>Tafsir al-Ahlam</div>
          <h1 style={{ fontFamily:"'Amiri',serif", fontSize:'clamp(1.8rem,5vw,2.5rem)', fontWeight:700, color:'var(--text)', marginBottom:4 }}>Interpréter mon rêve</h1>
          <p style={{ color:'var(--text-muted)', fontSize:13 }}>Sheikh Momar · Ibn Sirin · Al-Nabulsi</p>
          {user && !showPaywall && <div style={{ marginTop:8 }}><AccessBadge /></div>}
        </div>

        {showPaywall && (
          <div className="card" style={{ overflow:'hidden' }}>
            {/* P2 : hook personnalisé chargé depuis l'IA */}
            <Paywall user={user} dreamId={dreamId} hookText={hookText} form={form} />
          </div>
        )}

        {!showPaywall && (
          <>
            {(step <= TOTAL || step === '4.5') && (
              <div style={{ display:'flex', justifyContent:'center', gap:6, marginBottom:24 }}>
                {[1,2,3,4].map(n => <div key={n} className={`dot${n < step || step === '4.5' && n <= 3 ? ' done' : n === step ? ' active' : ''}`}/>)}
              </div>
            )}

            {step === 1 && (
              <div className="card p-6 up">
                <p className="label-sm mb-1" style={{color:'var(--blue)'}}>Étape 1 / {TOTAL}</p>
                <h2 style={{fontFamily:"'Amiri',serif",fontSize:'1.4rem',fontWeight:700,color:'var(--text)',marginBottom:16}}>Décrivez votre rêve</h2>
                <div style={{position:'relative',marginBottom:8}}>
                  <textarea value={form.text} onChange={e=>patch('text',e.target.value)}
                    className="field" style={{minHeight:180,resize:'none'}}
                    placeholder="J'ai rêvé que je me trouvais dans une grande mosquée blanche…"
                    maxLength={3000} autoFocus/>
                  <span style={{position:'absolute',bottom:12,right:14,fontSize:11,color:'var(--text-muted)'}}>{form.text.length}/3000</span>
                </div>
                {form.text.length > 0 && form.text.length < 40 && (
                  <p style={{fontSize:12,color:'var(--gold)',marginBottom:10}}>Minimum 40 caractères pour une analyse précise</p>
                )}
                <button onClick={()=>setStep(2)} disabled={!canGo()} className="btn btn-primary" style={{width:'100%',padding:'14px',fontSize:15,borderRadius:12}}>
                  Continuer <ChevronRight size={18}/>
                </button>
              </div>
            )}

            {step === 2 && (
              <div className="card p-6 up">
                <p className="label-sm mb-1" style={{color:'var(--blue)'}}>Étape 2 / {TOTAL}</p>
                <h2 style={{fontFamily:"'Amiri',serif",fontSize:'1.4rem',fontWeight:700,color:'var(--text)',marginBottom:6}}>Émotion ressentie</h2>
                <p style={{color:'var(--text-muted)',fontSize:13,marginBottom:18}}>Ibn Sirin accordait une importance capitale à l'émotion.</p>
                <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,marginBottom:24}}>
                  {EMOTIONS.map(e => (
                    <button key={e.label} onClick={()=>patch('emotion',e.label)} className={`emo-btn${form.emotion===e.label?' on':''}`}>
                      <div style={{fontSize:22,marginBottom:4}}>{e.emoji}</div>
                      <div style={{fontSize:11}}>{e.label}</div>
                    </button>
                  ))}
                </div>
                <div style={{display:'flex',gap:10}}>
                  <button onClick={()=>setStep(1)} className="btn btn-outline" style={{padding:'12px 16px',borderRadius:12}}><ChevronLeft size={18}/></button>
                  <button onClick={()=>setStep(3)} disabled={!canGo()} className="btn btn-primary" style={{flex:1,padding:'12px',borderRadius:12}}>Continuer <ChevronRight size={18}/></button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="card p-6 up">
                <p className="label-sm mb-1" style={{color:'var(--blue)'}}>Étape 3 / {TOTAL}</p>
                <h2 style={{fontFamily:"'Amiri',serif",fontSize:'1.4rem',fontWeight:700,color:'var(--text)',marginBottom:8}}>Moment du rêve</h2>
                <div style={{padding:'12px 16px',background:'var(--gold-pale)',border:'1px solid #FDE68A',borderRadius:10,marginBottom:18,fontSize:13,color:'var(--text-2)'}}>
                  ﷺ <em style={{color:'var(--gold)'}}>«Les rêves les plus véridiques surviennent avant Fajr.»</em> — Muslim
                </div>
                <div style={{display:'flex',flexDirection:'column',gap:8,marginBottom:24}}>
                  {TIMES.map(t => (
                    <button key={t.v} onClick={()=>patch('time',t.v)}
                      style={{display:'flex',alignItems:'center',gap:12,padding:'12px 16px',borderRadius:12,border:'1.5px solid',textAlign:'left',cursor:'pointer',background:form.time===t.v?'var(--green-pale)':'#fff',borderColor:form.time===t.v?'var(--green)':'var(--card-border)',transition:'all .18s'}}>
                      <span style={{fontSize:18}}>{t.star?'⭐':'🌑'}</span>
                      <div style={{flex:1}}>
                        <div style={{fontWeight:600,fontSize:14,color:form.time===t.v?'var(--green)':'var(--text)',marginBottom:2}}>{t.label}</div>
                        <div style={{fontSize:12,color:'var(--text-muted)'}}>{t.hint}{t.star?' — Heure la plus bénie':''}</div>
                      </div>
                      {form.time===t.v && <CheckCircle size={17} style={{color:'var(--green)'}}/>}
                    </button>
                  ))}
                </div>
                <div style={{display:'flex',gap:10}}>
                  <button onClick={()=>setStep(2)} className="btn btn-outline" style={{padding:'12px 16px',borderRadius:12}}><ChevronLeft size={18}/></button>
                  <button onClick={goFromStep3} disabled={!canGo()} className="btn btn-primary" style={{flex:1,padding:'12px',borderRadius:12}}>
                    {user ? <>Continuer <ChevronRight size={18}/></> : <>Continuer → Email <ChevronRight size={18}/></>}
                  </button>
                </div>
              </div>
            )}

            {/* P1 : EmailGate — s'affiche si pas encore connecté */}
            {step === '4.5' && (
              <div className="up">
                <EmailGate onSubmit={handleEmailSubmit} loading={authLoading} error={authError} />
                <button onClick={()=>setStep(3)} style={{background:'none',border:'none',color:'var(--text-muted)',fontSize:13,cursor:'pointer',marginTop:12,textDecoration:'underline',display:'block',margin:'12px auto 0'}}>
                  ← Retour
                </button>
              </div>
            )}

            {step === 4 && (
              <div className="card p-6 up">
                <p className="label-sm mb-1" style={{color:'var(--blue)'}}>Étape 4 / {TOTAL}</p>
                <h2 style={{fontFamily:"'Amiri',serif",fontSize:'1.4rem',fontWeight:700,color:'var(--text)',marginBottom:16}}>Confirmation</h2>
                <div style={{background:'var(--bg)',border:'1.5px solid var(--card-border)',borderRadius:12,padding:16,marginBottom:14}}>
                  <p style={{fontSize:13,color:'var(--text-3)',marginBottom:6}}><strong>Email :</strong> {user?.email}</p>
                  <p style={{fontSize:13,color:'var(--text-2)',marginBottom:6}}><strong>Rêve :</strong> <em>"{form.text.slice(0,80)}{form.text.length>80?'…':''}"</em></p>
                  <p style={{fontSize:13,color:'var(--text-2)'}}><strong>Émotion :</strong> {form.emotion} · <strong>Moment :</strong> {TIMES.find(t=>t.v===form.time)?.label}</p>
                </div>
                <div style={{padding:'12px 14px',background:'var(--green-pale)',border:'1px solid #A7F3D0',borderRadius:10,marginBottom:14,fontSize:13,color:'var(--text-2)'}}>
                  🎁 <strong>Analyse gratuite</strong> — Sheikh Momar · Ibn Sirin & Al-Nabulsi · 420+ mots
                </div>
                {error && (
                  <div style={{display:'flex',alignItems:'flex-start',gap:8,padding:'10px 14px',background:'var(--error-bg)',border:'1px solid var(--error-border)',borderRadius:10,marginBottom:14,fontSize:13,color:'var(--error-text)'}}>
                    <AlertCircle size={15} style={{flexShrink:0,marginTop:1}}/>{error}
                  </div>
                )}
                <div style={{display:'flex',gap:10}}>
                  <button onClick={()=>setStep(3)} className="btn btn-outline" style={{padding:'12px 16px',borderRadius:12}}><ChevronLeft size={18}/></button>
                  <button onClick={submit} disabled={loading} className="btn btn-primary" style={{flex:1,padding:'14px',fontSize:15,borderRadius:12}}>
                    {loading ? <><span className="spin" style={{width:18,height:18,border:'2px solid rgba(255,255,255,.3)',borderTopColor:'#fff'}}/> Analyse…</> : <><Moon size={18}/> Obtenir l'interprétation</>}
                  </button>
                </div>
              </div>
            )}

            {step === 5 && result && (
              <div className="up">
                <ResultView result={result} form={form} dreamId={dreamId} onRestart={restart} user={user}/>
              </div>
            )}
          </>
        )}

        {loading && (
          <div style={{position:'fixed',inset:0,zIndex:50,display:'flex',alignItems:'center',justifyContent:'center',padding:16,background:'rgba(255,255,255,.92)',backdropFilter:'blur(4px)'}}>
            <div className="card" style={{padding:40,textAlign:'center',maxWidth:320,width:'100%'}}>
              <div className="float" style={{fontSize:52,marginBottom:16}}>🌙</div>
              <div style={{fontFamily:"'Amiri',serif",fontSize:'1.3rem',fontWeight:700,color:'var(--text)',marginBottom:8}}>Consultation en cours…</div>
              <p style={{color:'var(--text-muted)',fontSize:13,marginBottom:20}}>Sheikh Momar analyse selon Ibn Sirin et Al-Nabulsi</p>
              <div style={{display:'flex',justifyContent:'center'}}><div className="spin"/></div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
