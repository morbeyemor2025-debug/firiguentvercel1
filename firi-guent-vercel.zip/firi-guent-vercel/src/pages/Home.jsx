import React, { useState, useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { Star, ChevronDown, ChevronUp, Lock, Zap, Shield, Clock, Gift, ArrowRight } from 'lucide-react'
import { PACKS, waPayLink, waExpertLink } from '../utils/constants.js'
import PrayerWidget from '../components/PrayerWidget.jsx'
import IslamicCalendar from '../components/IslamicCalendar.jsx'

// ─── WA Icon ─────────────────────────────────────────────────────
const WaIcon = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.127.558 4.126 1.533 5.859L.057 23.62a.5.5 0 00.598.65l5.956-1.558A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22a9.944 9.944 0 01-5.13-1.415l-.363-.217-3.773.987.997-3.676-.237-.378A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
  </svg>
)

// ─── Countdown timer ──────────────────────────────────────────────
function Countdown() {
  const getTime = () => {
    const stored = localStorage.getItem('fg_countdown')
    if (stored) {
      const end = parseInt(stored)
      const diff = end - Date.now()
      if (diff > 0) return diff
    }
    const end = Date.now() + 23 * 3600000 + 47 * 60000
    localStorage.setItem('fg_countdown', end.toString())
    return end - Date.now()
  }
  const [ms, setMs] = useState(getTime)
  useEffect(() => {
    const t = setInterval(() => setMs(getTime()), 1000)
    return () => clearInterval(t)
  }, [])
  const h = Math.floor(ms / 3600000)
  const m = Math.floor((ms % 3600000) / 60000)
  const s = Math.floor((ms % 60000) / 1000)
  const pad = n => String(n).padStart(2, '0')
  return (
    <span className="font-mono font-bold" style={{ color: '#EF4444' }}>
      {pad(h)}:{pad(m)}:{pad(s)}
    </span>
  )
}

// ─── Testimonials ─────────────────────────────────────────────────
const TESTIMONIALS = [
  {
    avatar: 'https://i.ibb.co/pvx1ng1L/avatar-homme-noir-1.jpg',
    name: 'Ibrahima S.', city: 'Dakar', stars: 5,
    text: 'J\'avais rêvé d\'un serpent dans ma maison depuis 3 semaines. Firi Guent m\'a expliqué exactement ce que signifiait ce signe. Ibn Sirin avait tout prédit. La réponse m\'a changé.',
  },
  {
    avatar: 'https://i.ibb.co/SXjgNHCz/avatar-femme.jpg',
    name: 'Aïssatou K.', city: 'Saint-Louis', stars: 5,
    text: 'J\'ai reçu l\'analyse complète sur WhatsApp en quelques minutes. La précision est incroyable. Ce rêve était vraiment un avertissement d\'Allah. Alhamdulillah, j\'ai évité un problème majeur.',
  },
  {
    avatar: 'https://i.ibb.co/xRm4jfB/avatar-homme-blanc1.jpg',
    name: 'Mamadou B.', city: 'Thiès', stars: 5,
    text: 'Sheikh Momar a cité exactement les mêmes références qu\'un imam que j\'avais consulté. Mais là c\'est disponible à 2h du matin. Le service premium vaut largement son prix.',
  },
]

// ─── FAQ ──────────────────────────────────────────────────────────
const FAQS = [
  { q: 'Est-ce vraiment basé sur Ibn Sirin ?', a: 'Oui. Chaque interprétation s\'appuie directement sur les œuvres d\'Ibn Sirin (Tafsir al-Ahlam) et d\'Al-Nabulsi (At-Ta\'bir fi ar-Ru\'ya). Les citations sont précises et vérifiables. Sheikh Momar suit la même méthodologie que ces grands savants.' },
  { q: 'Mon rêve est-il vraiment confidentiel ?', a: 'Absolument. Vos rêves sont stockés uniquement sur votre appareil (localStorage). Ils ne sont jamais partagés ni vendus. Seul l\'analyse est traitée de manière sécurisée.' },
  { q: 'Pourquoi payer pour la version complète ?', a: 'La version gratuite vous donne le symbole central et son interprétation de base. La version complète inclut tous les symboles secondaires, les hadiths authentiques, les cas historiques des Compagnons du Prophète ﷺ, et les prescriptions spirituelles personnalisées. C\'est une différence fondamentale.' },
  { q: 'Comment fonctionne le paiement Wave ?', a: 'Vous envoyez le montant par Wave, vous joignez une capture d\'écran dans votre message WhatsApp avec la référence de votre rêve. Sheikh Momar confirme et vous envoie l\'analyse complète. Simple, rapide, sécurisé.' },
  { q: 'Combien de temps pour recevoir la réponse ?', a: 'Pour la version gratuite, instantanément. Pour la version premium, dès confirmation du paiement Wave — généralement en moins de 30 minutes. In sha Allah.' },
  { q: 'Et si mon rêve n\'est pas dans le dictionnaire ?', a: 'Vous pouvez nous contacter directement sur WhatsApp. Nos experts sénégalais analyseront votre rêve spécifique et vous répondront personnellement. In sha Allah.' },
]

export default function Home() {
  const [openFaq, setOpenFaq] = useState(null)
  const [spotsLeft] = useState(7)
  const interpretRef = useRef(null)

  const scrollToInterpret = () => {
    document.getElementById('section-interpret')?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <div className="z1" style={{ fontFamily: "'Inter', 'Cormorant Garamond', sans-serif" }}>

      {/* ══════════════════════════════════════════════════════════
          URGENCY BAR
      ══════════════════════════════════════════════════════════ */}
      <div style={{ background: '#991B1B', color: '#fff', textAlign: 'center', padding: '10px 16px', fontSize: 13, fontWeight: 600, position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100 }}>
        ⚡ Offre limitée : analyse complète offerte aux <strong>{spotsLeft} prochains</strong> nouveaux membres · Expire dans <Countdown />
      </div>

      {/* ══════════════════════════════════════════════════════════
          HERO — ULTRA PUISSANT
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background: 'var(--bg-hero)', paddingTop: 80, paddingBottom: 80, minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>

        {/* Background moon */}
        <div style={{ position: 'absolute', right: -60, top: 60, opacity: .05, pointerEvents: 'none', fontSize: 400, lineHeight: 1, userSelect: 'none' }}>🌙</div>

        <div className="z1 px-4 w-full max-w-4xl mx-auto">

          {/* Badge autorité */}
          <div className="up d1 mb-5 flex justify-center">
            <span style={{ background: 'rgba(16,185,129,.15)', color: '#6EE7B7', border: '1px solid rgba(16,185,129,.35)', borderRadius: 24, padding: '7px 18px', fontSize: 13, fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 8 }}>
              🇸🇳 Basé sur Ibn Sirin · Al-Nabulsi · Tradition islamique authentique
            </span>
          </div>

          {/* Titre choc */}
          <h1 className="up d2" style={{ color: '#F9FAFB', fontSize: 'clamp(2.2rem, 7vw, 4.5rem)', fontFamily: "'Amiri', Georgia, serif", fontWeight: 700, lineHeight: 1.15, marginBottom: 20 }}>
            Votre rêve n'est pas<br />
            un hasard.
            <br />
            <span style={{ color: '#6EE7B7' }}>Allah vous envoie un message.</span>
          </h1>

          {/* Sous-titre */}
          <p className="up d3" style={{ color: '#D1D5DB', fontSize: 'clamp(1rem, 2.5vw, 1.3rem)', maxWidth: 620, margin: '0 auto 28px', lineHeight: 1.7 }}>
            Chaque nuit, vos rêves portent des <strong style={{ color: '#FDE68A' }}>signes, avertissements et guidances</strong> d'Allah.
            Ignorer ces messages, c'est passer à côté de ce qu'Il vous révèle.
          </p>

          {/* Hadith autorité */}
          <div className="up d3 mb-8" style={{ maxWidth: 520, margin: '0 auto 32px' }}>
            <div style={{ background: 'rgba(254,243,199,.08)', border: '1px solid rgba(253,230,138,.25)', borderRadius: 14, padding: '16px 22px' }}>
              <div style={{ fontFamily: "'Scheherazade New', serif", fontSize: '1.2rem', color: '#FDE68A', direction: 'rtl', marginBottom: 6 }}>
                رُؤْيَا الْمُؤْمِنِ جُزْءٌ مِنْ سِتَّةٍ وَأَرْبَعِينَ جُزْءًا مِنَ النُّبُوَّةِ
              </div>
              <div style={{ fontFamily: "'Amiri', serif", color: '#86EFAC', fontSize: '.9rem', fontStyle: 'italic' }}>
                "Le rêve du croyant est une partie des 46 parties de la prophétie."
              </div>
              <div style={{ color: '#6B7280', fontSize: 11, marginTop: 4 }}>— Bukhari & Muslim — Hadith authentique</div>
            </div>
          </div>

          {/* CTA principal */}
          <div className="up d4 flex flex-col sm:flex-row gap-3 justify-center">
            <Link to="/login" className="btn btn-primary blue-pulse" style={{ fontSize: 17, padding: '16px 36px', borderRadius: 14, fontFamily: "'Amiri', serif", minHeight: 56 }}>
              🌙 Interpréter mon rêve gratuitement
            </Link>
            <a href={waExpertLink('')} target="_blank" rel="noreferrer"
              className="btn btn-wa wa-pulse justify-center" style={{ fontSize: 16, padding: '16px 28px', borderRadius: 14, minHeight: 56 }}>
              <WaIcon /> Parler à un expert
            </a>
          </div>

          <p className="up d5 mt-4" style={{ color: '#6B7280', fontSize: 13 }}>
            ✓ 1ère interprétation gratuite · ✓ Sans inscription · ✓ Confidentiel · ✓ Résultat immédiat
          </p>

          {/* Social proof mini */}
          <div className="up d5 mt-6 flex flex-wrap justify-center items-center gap-4" style={{ color: '#9CA3AF', fontSize: 13 }}>
            <div className="flex -space-x-2">
              {[TESTIMONIALS[0].avatar, TESTIMONIALS[1].avatar, TESTIMONIALS[2].avatar].map((src, i) => (
                <img key={i} src={src} alt="" style={{ width: 32, height: 32, borderRadius: '50%', border: '2px solid #0C1F14', objectFit: 'cover' }} />
              ))}
            </div>
            <span><span style={{ color: '#FDE68A', fontWeight: 700 }}>+3 200</span> rêves interprétés · 4.9★</span>
            <span style={{ color: '#374151' }}>·</span>
            <span>🇸🇳 Dakar · Sénégal</span>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          PROBLÈME — Peur + Curiosité
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background: 'var(--bg-alt)', padding: '72px 16px' }}>
        <div style={{ maxWidth: 720, margin: '0 auto', textAlign: 'center' }}>
          <div className="label-sm mb-3" style={{ color: '#991B1B' }}>⚠️ Le problème que personne ne dit</div>
          <h2 style={{ color: 'var(--text)', fontFamily: "'Amiri', serif", fontSize: 'clamp(1.6rem, 4vw, 2.5rem)', fontWeight: 700, marginBottom: 20, lineHeight: 1.3 }}>
            Vous avez fait un rêve cette nuit.<br />
            Vous l'avez ignoré.<br />
            <span style={{ color: '#991B1B' }}>C'était peut-être une erreur.</span>
          </h2>
          <p style={{ color: 'var(--text-3)', fontSize: '1.1rem', lineHeight: 1.8, marginBottom: 32 }}>
            Dans la tradition islamique, les rêves ne sont pas des illusions de votre cerveau.
            Ibn Sirin — le plus grand savant de l'interprétation des rêves — a passé 40 ans à documenter leur signification.
            <strong style={{ color: 'var(--text-2)' }}> Il savait quelque chose que la plupart des gens ignorent encore aujourd'hui.</strong>
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16 }}>
            {[
              { icon: '😨', title: 'Un rêve de serpent', text: "Peut signaler un ennemi caché dans votre entourage que vous n'avez pas encore identifié." },
              { icon: '🌊', title: 'Un rêve d\'eau trouble', text: "Ibn Sirin dit : des épreuves imminentes approchent. Votre rêve vous prévenait." },
              { icon: '🏠', title: 'Une maison qui s\'effondre', text: "C'est rarement anodin. Cela peut concerner votre santé, votre famille ou votre foi." },
              { icon: '🌙', title: 'Voir le Prophète ﷺ', text: "Un des rêves les plus bénis. Mais seulement si vous en comprenez le message." },
            ].map((item, i) => (
              <div key={i} className="card" style={{ padding: '20px 16px', textAlign: 'left' }}>
                <div style={{ fontSize: 28, marginBottom: 10 }}>{item.icon}</div>
                <div style={{ fontWeight: 700, color: 'var(--text)', marginBottom: 6, fontSize: 15 }}>{item.title}</div>
                <p style={{ color: 'var(--text-3)', fontSize: 13, lineHeight: 1.6, margin: 0 }}>{item.text}</p>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 36, padding: '20px 24px', background: '#FEF2F2', border: '2px solid #FCA5A5', borderRadius: 14 }}>
            <p style={{ color: '#991B1B', fontWeight: 700, fontSize: '1.05rem', margin: 0 }}>
              ⚡ Chaque rêve non interprété est un message non lu.<br />
              <span style={{ fontWeight: 400, color: '#B91C1C', fontSize: '0.95rem' }}>Combien de signes avez-vous déjà manqués ?</span>
            </p>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          SOLUTION — Présentation produit
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background: 'var(--card)', padding: '72px 16px' }}>
        <div style={{ maxWidth: 880, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <div className="label-sm mb-3" style={{ color: 'var(--green)' }}>💡 La solution</div>
            <h2 style={{ color: 'var(--text)', fontFamily: "'Amiri', serif", fontSize: 'clamp(1.6rem, 4vw, 2.5rem)', fontWeight: 700, marginBottom: 16, lineHeight: 1.3 }}>
              Firi Guent — Le seul outil d'interprétation<br />
              islamique disponible <span style={{ color: 'var(--blue)' }}>24h/24 au Sénégal</span>
            </h2>
            <p style={{ color: 'var(--text-3)', fontSize: '1.1rem', maxWidth: 600, margin: '0 auto', lineHeight: 1.75 }}>
              Basé sur <strong>1 400 ans de science islamique</strong>. Analyses rigoureuses selon Ibn Sirin et Al-Nabulsi.
              Disponible à 3h du matin quand votre rêve vous réveille.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: 20 }}>
            {[
              { icon: '📖', color: '#1E40AF', bg: '#DBEAFE', title: 'Ibn Sirin & Al-Nabulsi', desc: 'Les deux références absolues. Citations exactes. Méthode millénaire préservée intacte.' },
              { icon: '⚡', color: '#065F46', bg: '#D1FAE5', title: 'Réponse immédiate', desc: 'Le symbole central identifié en secondes. Disponible à 3h du matin, 7j/7.' },
              { icon: '🔒', color: '#78350F', bg: '#FEF3C7', title: '100% confidentiel', desc: 'Vos rêves ne quittent jamais votre appareil. Personne ne lit vos rêves sauf Sheikh Momar.' },
              { icon: '🇸🇳', color: '#991B1B', bg: '#FEE2E2', title: 'Ancrage sénégalais', desc: 'Nos experts locaux intègrent les valeurs culturelles, le dhikr, la sadaqa et la guidance spirituelle.' },
            ].map((f, i) => (
              <div key={i} className="card" style={{ padding: '24px', display: 'flex', gap: 16, alignItems: 'flex-start' }}>
                <div style={{ width: 48, height: 48, borderRadius: 12, background: f.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, flexShrink: 0 }}>
                  {f.icon}
                </div>
                <div>
                  <div style={{ fontWeight: 700, color: 'var(--text)', marginBottom: 6, fontSize: 15 }}>{f.title}</div>
                  <p style={{ color: 'var(--text-3)', fontSize: 13, lineHeight: 1.6, margin: 0 }}>{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          COMMENT ÇA MARCHE — 3 étapes
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background: 'var(--bg)', padding: '72px 16px' }}>
        <div style={{ maxWidth: 860, margin: '0 auto', textAlign: 'center' }}>
          <div className="label-sm mb-3" style={{ color: 'var(--blue)' }}>Comment ça marche</div>
          <h2 style={{ color: 'var(--text)', fontFamily: "'Amiri', serif", fontSize: 'clamp(1.5rem, 4vw, 2.2rem)', fontWeight: 700, marginBottom: 48, lineHeight: 1.3 }}>
            3 étapes. 3 minutes. Une réponse claire.
          </h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 32 }}>
            {[
              { n: '1', emoji: '✍️', title: 'Décrivez votre rêve', desc: 'Racontez les détails : symboles, personnes, lieux, émotions ressenties. Plus c\'est précis, plus l\'analyse est puissante.' },
              { n: '2', emoji: '🔍', title: 'Sheikh Momar analyse', desc: 'Notre IA formée sur les textes d\'Ibn Sirin identifie le symbole maître et construit l\'interprétation complète.' },
              { n: '3', emoji: '💬', title: 'Recevez la réponse', desc: 'Instantanément pour la version gratuite. Sur WhatsApp après paiement Wave pour l\'analyse complète.' },
            ].map((s, i) => (
              <div key={i} style={{ textAlign: 'center' }}>
                <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'var(--blue)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, fontWeight: 700, margin: '0 auto 16px', fontFamily: "'Inter', sans-serif" }}>{s.n}</div>
                <div style={{ fontSize: 36, marginBottom: 12 }}>{s.emoji}</div>
                <div style={{ fontWeight: 700, color: 'var(--text)', marginBottom: 8, fontSize: 17 }}>{s.title}</div>
                <p style={{ color: 'var(--text-3)', fontSize: 14, lineHeight: 1.7, margin: 0 }}>{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          PAYWALL STRATÉGIQUE — Frustration + envie
      ══════════════════════════════════════════════════════════ */}
      <section id="section-interpret" style={{ background: 'var(--bg-alt)', padding: '72px 16px' }}>
        <div style={{ maxWidth: 720, margin: '0 auto', textAlign: 'center' }}>
          <div className="label-sm mb-3" style={{ color: 'var(--gold)' }}>Aperçu d'une analyse</div>
          <h2 style={{ color: 'var(--text)', fontFamily: "'Amiri', serif", fontSize: 'clamp(1.5rem, 4vw, 2.2rem)', fontWeight: 700, marginBottom: 8, lineHeight: 1.3 }}>
            Voici ce que vous allez recevoir
          </h2>
          <p style={{ color: 'var(--text-3)', marginBottom: 32, fontSize: '1.05rem' }}>
            (Exemple réel d'une analyse pour un rêve de serpent)
          </p>

          {/* Analyse gratuite - visible */}
          <div className="card" style={{ padding: '28px 28px 20px', textAlign: 'left', marginBottom: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <span style={{ background: 'var(--green-pale)', color: 'var(--green-text)', border: '1px solid #6EE7B7', borderRadius: 20, padding: '4px 12px', fontSize: 12, fontWeight: 700 }}>
                🎁 Version gratuite — visible
              </span>
            </div>
            <div style={{ borderBottom: '2px solid var(--green-pale)', paddingBottom: 8, marginBottom: 14 }}>
              <span style={{ fontFamily: "'Amiri', serif", fontSize: '1.2rem', fontWeight: 700, color: 'var(--green)' }}>🌙 Le symbole central : Thu'bân — الثُّعْبَان (Serpent)</span>
            </div>
            <p style={{ color: 'var(--text-3)', lineHeight: 1.8, fontSize: '1rem', marginBottom: 12 }}>
              Selon Ibn Sirin dans son <em>Tafsir al-Ahlam</em>, le serpent est l'un des symboles les plus complexes et les plus importants du Tafsir al-Ahlam. Sa signification dépend fortement du contexte, de la couleur et du comportement de l'animal dans le rêve.
            </p>
            <p style={{ color: 'var(--text-3)', lineHeight: 1.8, fontSize: '1rem', marginBottom: 12 }}>
              Dans votre rêve, la présence du serpent <strong style={{ color: 'var(--text-2)' }}>à l'intérieur de votre maison</strong> est particulièrement significative. Ibn Sirin précise que cette configuration représente généralement <strong style={{ color: 'var(--text-2)' }}>un ennemi proche, peut-être quelqu'un en qui vous avez confiance</strong>...
            </p>

            {/* PAYWALL BLUR */}
            <div style={{ position: 'relative', marginTop: 8 }}>
              <div style={{ filter: 'blur(5px)', userSelect: 'none', pointerEvents: 'none', color: 'var(--text-3)', lineHeight: 1.8, fontSize: '1rem' }}>
                <p style={{ marginBottom: 12 }}>
                  Al-Nabulsi ajoute une précision cruciale : si le serpent dans votre rêve était de couleur XXXXXXXXX, cela indique XXXXXXXXXXXXXXXXX. La direction dans laquelle il se déplaçait révèle XXXXXXXXXXXXXXXXXXXXXXXXX.
                </p>
                <p style={{ marginBottom: 12 }}>
                  📜 Hadith : Le Prophète ﷺ a dit : "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" (Bukhari n°XXXX). Ce hadith s'applique directement à votre situation car XXXXXXXXXXXXXXXXXX.
                </p>
                <p style={{ marginBottom: 12 }}>
                  🕌 Cas historique : Le Calife XXXXXXXXXX a eu une vision similaire. Ibn Sirin lui a répondu : XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.
                </p>
                <p>🤲 Prescription spirituelle : Je vous recommande de lire XXXXXXXX fois la sourate XXXXXX pendant XXXXXXXX jours. In sha Allah, vous ressentirez XXXXXXXXXXXXXXXXXXXXXXXXX.</p>
              </div>

              {/* Unlock overlay */}
              <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: 'rgba(255,255,255,.7)', backdropFilter: 'blur(2px)', borderRadius: 12 }}>
                <Lock size={32} style={{ color: 'var(--blue)', marginBottom: 10 }} />
                <div style={{ fontWeight: 700, fontSize: 16, color: 'var(--text)', marginBottom: 6 }}>La suite est réservée à l'analyse complète</div>
                <div style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 16, textAlign: 'center', maxWidth: 280 }}>
                  Hadiths · Cas historiques · Prescriptions spirituelles · Consultation experts
                </div>
                <Link to="/login" className="btn btn-primary" style={{ padding: "12px 28px", fontSize: 15 }}>
                  🔓 Débloquer l'analyse complète — 1 000 FCFA
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          PRICING — 3 offres claires
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background: 'var(--card)', padding: '72px 16px' }} id="pricing">
        <div style={{ maxWidth: 960, margin: '0 auto', textAlign: 'center' }}>
          <div className="label-sm" style={{ color: 'var(--blue)', marginBottom: 8 }}>Tarifs transparents</div>
          <h2 style={{ color: 'var(--text)', fontFamily: "'Amiri', serif", fontSize: 'clamp(1.6rem, 4vw, 2.4rem)', fontWeight: 700, marginBottom: 10, lineHeight: 1.2 }}>
            Simple. Juste. Islamique.
          </h2>
          <p style={{ color: 'var(--text-3)', marginBottom: 12, fontSize: '1rem', maxWidth: 500, margin: '0 auto 12px' }}>
            1 interprétation gratuite · Paiement unique ou abonnement illimité · Via Wave
          </p>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: '#FEF2F2', border: '1px solid #FCA5A5', borderRadius: 24, padding: '6px 16px', marginBottom: 44, fontSize: 13, color: '#991B1B', fontWeight: 600 }}>
            <Clock size={13} /> Offre limitée — expire dans <Countdown />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 20, alignItems: 'stretch' }}>

            {/* ── GRATUIT ── */}
            <div className="card" style={{ padding: '28px 24px', textAlign: 'left', display: 'flex', flexDirection: 'column' }}>
              <div className="label-sm" style={{ color: 'var(--text-muted)', marginBottom: 10 }}>Découverte</div>
              <div style={{ fontFamily: "'Amiri', serif", fontSize: 42, fontWeight: 700, color: 'var(--text)', lineHeight: 1, marginBottom: 4 }}>Gratuit</div>
              <div style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 20 }}>Pour essayer · Sans engagement</div>
              <ul style={{ listStyle: 'none', padding: 0, marginBottom: 'auto' }}>
                {[
                  '1 interprétation offerte',
                  'Symbole central identifié',
                  'Référence Ibn Sirin / Al-Nabulsi',
                  'Analyse 420+ mots',
                  "Conseil spirituel + du'a",
                ].map((t, i) => (
                  <li key={i} style={{ display: 'flex', gap: 8, marginBottom: 8, color: 'var(--text-3)', fontSize: 13, alignItems: 'flex-start' }}>
                    <span style={{ color: 'var(--green)', fontWeight: 700, flexShrink: 0, marginTop: 1 }}>✓</span>{t}
                  </li>
                ))}
                {['Symboles secondaires', 'Hadiths Bukhari/Muslim', "Cas des Compagnons ﷺ", 'Experts sénégalais'].map((t, i) => (
                  <li key={i} style={{ display: 'flex', gap: 8, marginBottom: 8, color: '#9CA3AF', fontSize: 13, alignItems: 'flex-start' }}>
                    <span style={{ color: '#D1D5DB', flexShrink: 0, marginTop: 1 }}>○</span>{t}
                  </li>
                ))}
              </ul>
              <Link to="/login" className="btn btn-outline-green" style={{ width: '100%', justifyContent: 'center', padding: '13px', marginTop: 20, borderRadius: 12 }}>
                Commencer gratuitement
              </Link>
            </div>

            {/* ── PAIEMENT UNIQUE 1000 FCFA ── */}
            <div style={{ padding: '28px 24px', textAlign: 'left', display: 'flex', flexDirection: 'column', position: 'relative', borderRadius: 18, border: '2.5px solid var(--blue)', boxShadow: '0 8px 32px rgba(30,64,175,.18)', background: '#fff' }}>
              <div style={{ position: 'absolute', top: -13, left: '50%', transform: 'translateX(-50%)', background: 'var(--blue)', color: '#fff', borderRadius: 20, padding: '4px 16px', fontSize: 12, fontWeight: 700, whiteSpace: 'nowrap' }}>
                ⭐ Le plus populaire
              </div>
              <div className="label-sm" style={{ color: 'var(--blue)', marginBottom: 10 }}>Paiement unique</div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 4 }}>
                <span style={{ fontFamily: "'Amiri', serif", fontSize: 42, fontWeight: 700, color: 'var(--blue)', lineHeight: 1 }}>1 000</span>
                <span style={{ color: 'var(--text-muted)', fontSize: 15 }}>FCFA</span>
              </div>
              <div style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 20 }}>1 interprétation complète · Sans abonnement</div>
              <ul style={{ listStyle: 'none', padding: 0, marginBottom: 'auto' }}>
                {[
                  'Tout du plan gratuit',
                  'Tous les symboles analysés',
                  'Hadiths Bukhari/Muslim cités',
                  "Cas des Compagnons ﷺ",
                  "Du'a : arabe + phonétique + traduction",
                  'Consultation experts sénégalais',
                ].map((t, i) => (
                  <li key={i} style={{ display: 'flex', gap: 8, marginBottom: 8, color: 'var(--text-3)', fontSize: 13, alignItems: 'flex-start' }}>
                    <span style={{ color: 'var(--green)', fontWeight: 700, flexShrink: 0, marginTop: 1 }}>✓</span>{t}
                  </li>
                ))}
              </ul>
              <a href={waPayLink({ label:'1 interprétation', fcfa:'1 000 FCFA', price:1000 }, '', '')} target="_blank" rel="noreferrer"
                className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '14px', marginTop: 20, borderRadius: 12, fontSize: 15, fontFamily: "'Amiri', serif" }}>
                <WaIcon size={16} /> Payer 1 000 FCFA — Wave
              </a>
            </div>

            {/* ── ABONNEMENT 5000 FCFA ── */}
            <div style={{ padding: '28px 24px', textAlign: 'left', display: 'flex', flexDirection: 'column', borderRadius: 18, border: '2px solid #A7F3D0', boxShadow: '0 4px 20px rgba(5,150,105,.12)', background: 'linear-gradient(135deg, #f0fdf4 0%, #fff 100%)' }}>
              <div className="label-sm" style={{ color: 'var(--green)', marginBottom: 10 }}>Abonnement mensuel</div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 4 }}>
                <span style={{ fontFamily: "'Amiri', serif", fontSize: 42, fontWeight: 700, color: 'var(--green)', lineHeight: 1 }}>5 000</span>
                <span style={{ color: 'var(--text-muted)', fontSize: 15 }}>FCFA / mois</span>
              </div>
              <div style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 8 }}>Accès illimité 30 jours · Renouvellement optionnel</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'var(--gold-pale)', border: '1px solid #FDE68A', borderRadius: 8, padding: '6px 10px', marginBottom: 16, fontSize: 12, fontWeight: 600, color: 'var(--gold-text)' }}>
                <Gift size={12} /> + Consultation Istikhar offerte
              </div>
              <ul style={{ listStyle: 'none', padding: 0, marginBottom: 'auto' }}>
                {[
                  'Interprétations ILLIMITÉES 30 jours',
                  'Tout du paiement unique',
                  'Priorité de réponse garantie',
                  'Istikhar personnalisé offert',
                  'Guidance spirituelle continue',
                  'Accès cercles de dhikr (dahira)',
                ].map((t, i) => (
                  <li key={i} style={{ display: 'flex', gap: 8, marginBottom: 8, color: 'var(--text-3)', fontSize: 13, alignItems: 'flex-start' }}>
                    <span style={{ color: 'var(--green)', fontWeight: 700, flexShrink: 0, marginTop: 1 }}>✓</span>{t}
                  </li>
                ))}
              </ul>
              <a href={waPayLink({ label:'Abonnement 30 jours illimité', fcfa:'5 000 FCFA', price:5000 }, '', '')} target="_blank" rel="noreferrer"
                className="btn btn-green" style={{ width: '100%', justifyContent: 'center', padding: '14px', marginTop: 20, borderRadius: 12, fontSize: 15, fontFamily: "'Amiri', serif" }}>
                <WaIcon size={16} /> Payer 5 000 FCFA — Wave
              </a>
            </div>
          </div>

          <p style={{ color: 'var(--text-muted)', fontSize: 12, marginTop: 20 }}>
            💳 Paiement Wave uniquement · Confirmation sur WhatsApp sous 30 min · <em style={{ color: 'var(--gold)' }}>In sha Allah</em>
          </p>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          TÉMOIGNAGES + PREUVES SOCIALES
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background: 'var(--bg)', padding: '72px 16px' }}>
        <div style={{ maxWidth: 940, margin: '0 auto', textAlign: 'center' }}>
          <div className="label-sm mb-3" style={{ color: 'var(--green)' }}>Ce qu'ils disent</div>
          <h2 style={{ color: 'var(--text)', fontFamily: "'Amiri', serif", fontSize: 'clamp(1.5rem, 4vw, 2.2rem)', fontWeight: 700, marginBottom: 12 }}>
            +3 200 musulmans ont compris leurs rêves
          </h2>
          <p style={{ color: 'var(--text-3)', marginBottom: 48, fontSize: '1rem' }}>
            Ils ont reçu des réponses claires. Des messages qu'ils attendaient sans le savoir.
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 20 }}>
            {TESTIMONIALS.map((t, i) => (
              <div key={i} className="card" style={{ padding: '24px', textAlign: 'left' }}>
                <div style={{ display: 'flex', gap: 4, marginBottom: 14 }}>
                  {[0,1,2,3,4].map(j => <Star key={j} size={14} style={{ fill: '#FBBF24', color: '#FBBF24' }} />)}
                </div>
                <p style={{ color: 'var(--text-3)', fontSize: 14, lineHeight: 1.75, marginBottom: 20, fontStyle: 'italic' }}>
                  " {t.text} "
                </p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <img src={t.avatar} alt={t.name} style={{ width: 44, height: 44, borderRadius: '50%', objectFit: 'cover', border: '2px solid var(--green-pale)' }} />
                  <div>
                    <div style={{ fontWeight: 700, color: 'var(--text)', fontSize: 14 }}>{t.name}</div>
                    <div style={{ color: 'var(--text-muted)', fontSize: 12 }}>{t.city}, Sénégal 🇸🇳</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* WhatsApp screenshot simulation */}
          <div style={{ marginTop: 48 }}>
            <p style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 20 }}>📱 Exemples de retours WhatsApp</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, justifyContent: 'center' }}>
              {[
                { msg: "MashAllah je suis sans mots. L'analyse était exactement ce dont j'avais besoin. Baraka Allahu fikoum 🤲", time: '14:32', read: true },
                { msg: "J'ai suivi les conseils du Sheikh. In sha Allah les choses vont s'arranger. Merci infiniment 🌙", time: '09:15', read: true },
                { msg: "Ce rêve me hantait depuis des jours. Maintenant je comprends. Alhamdulillah !", time: '03:47', read: true },
              ].map((m, i) => (
                <div key={i} style={{ background: '#ECF7EF', border: '1px solid #D1FAE5', borderRadius: '18px 18px 4px 18px', padding: '12px 16px', maxWidth: 280, textAlign: 'left', boxShadow: '0 2px 8px rgba(0,0,0,.06)' }}>
                  <p style={{ color: '#111827', fontSize: 14, lineHeight: 1.6, marginBottom: 8 }}>{m.msg}</p>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 4, color: '#6B7280', fontSize: 11 }}>
                    {m.time}
                    {m.read && <span style={{ color: '#34A853', fontSize: 13 }}>✓✓</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          PRAYER TIMES + CALENDAR
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background: 'var(--bg-alt)', padding: '56px 16px' }}>
        <div style={{ maxWidth: 900, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 32 }}>
            <div className="label-sm mb-2" style={{ color: 'var(--green)' }}>Outils islamiques</div>
            <h2 style={{ color: 'var(--text)', fontFamily: "'Amiri', serif", fontSize: '1.8rem', fontWeight: 700 }}>Horaires de prière & Calendrier</h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 20 }}>
            <PrayerWidget />
            <IslamicCalendar />
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          FAQ
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background: 'var(--card)', padding: '72px 16px' }}>
        <div style={{ maxWidth: 680, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 40 }}>
            <div className="label-sm mb-3" style={{ color: 'var(--blue)' }}>FAQ</div>
            <h2 style={{ color: 'var(--text)', fontFamily: "'Amiri', serif", fontSize: 'clamp(1.5rem, 4vw, 2.2rem)', fontWeight: 700 }}>
              Vos questions, nos réponses
            </h2>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {FAQS.map((faq, i) => (
              <div key={i} className="card" style={{ overflow: 'hidden' }}>
                <button onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, padding: '18px 22px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left' }}>
                  <span style={{ fontWeight: 600, color: 'var(--text)', fontSize: 15 }}>{faq.q}</span>
                  {openFaq === i ? <ChevronUp size={18} style={{ color: 'var(--blue)', flexShrink: 0 }} /> : <ChevronDown size={18} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />}
                </button>
                {openFaq === i && (
                  <div style={{ padding: '0 22px 18px', color: 'var(--text-3)', fontSize: 14, lineHeight: 1.75 }}>
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          CTA FINAL — Ultra convaincant
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background: 'var(--bg-hero)', padding: '80px 16px', textAlign: 'center' }}>
        <div style={{ maxWidth: 680, margin: '0 auto' }}>

          <div style={{ fontFamily: "'Scheherazade New', serif", fontSize: '2.5rem', color: 'rgba(253,230,138,.15)', marginBottom: 8, direction: 'rtl' }}>
            رُؤْيَا
          </div>

          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'rgba(239,68,68,.15)', color: '#FCA5A5', border: '1px solid rgba(239,68,68,.3)', borderRadius: 24, padding: '7px 18px', fontSize: 13, fontWeight: 700, marginBottom: 24 }}>
            ⏳ <Countdown /> restantes sur l'offre spéciale
          </div>

          <h2 style={{ color: '#F9FAFB', fontFamily: "'Amiri', serif", fontSize: 'clamp(1.8rem, 5vw, 3rem)', fontWeight: 700, lineHeight: 1.2, marginBottom: 20 }}>
            Ce rêve que vous avez fait<br />
            <span style={{ color: '#6EE7B7' }}>mérite une vraie réponse.</span>
          </h2>

          <p style={{ color: '#D1D5DB', fontSize: '1.1rem', lineHeight: 1.75, marginBottom: 12 }}>
            Des milliers de musulmans ont déjà compris ce que leurs rêves leur disaient.
            <strong style={{ color: '#FDE68A' }}> Certains ont évité des problèmes. D'autres ont saisi des opportunités.</strong>
          </p>
          <p style={{ color: '#9CA3AF', marginBottom: 40, fontSize: '1rem' }}>
            La première interprétation est <span style={{ color: '#6EE7B7', fontWeight: 700 }}>100% gratuite</span>. Sans carte. Sans inscription. In sha Allah, votre réponse vous attend.
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 14, alignItems: 'center' }}>
            <Link to="/login" className="btn btn-primary blue-pulse" style={{ fontSize: 18, padding: '18px 44px', borderRadius: 16, fontFamily: "'Amiri', serif", minHeight: 58, width: '100%', maxWidth: 460, justifyContent: 'center' }}>
              🌙 Interpréter mon rêve maintenant — Gratuit
            </Link>
            <a href={waExpertLink('')} target="_blank" rel="noreferrer"
              className="btn btn-wa wa-pulse justify-center" style={{ fontSize: 16, padding: '15px 36px', borderRadius: 14, minHeight: 52, width: '100%', maxWidth: 380 }}>
              <WaIcon /> Contacter un expert directement
            </a>
          </div>

          <div style={{ marginTop: 32, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 20, color: '#6B7280', fontSize: 13 }}>
            <span><Shield size={13} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 4 }} />Confidentiel</span>
            <span><Zap size={13} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 4 }} />Réponse immédiate</span>
            <span>🕌 Selon Ibn Sirin</span>
            <span>🇸🇳 Experts sénégalais</span>
          </div>
        </div>
      </section>

    </div>
  )
}
